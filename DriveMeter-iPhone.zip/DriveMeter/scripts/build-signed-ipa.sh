#!/bin/bash
set -euo pipefail
umask 077
: "${BUILD_CERTIFICATE_BASE64:?Set the repository signing certificate secret}"
: "${P12_PASSWORD:?Set the repository P12 password secret}"
: "${BUILD_PROVISION_PROFILE_BASE64:?Set the repository Ad Hoc profile secret}"
: "${RUNNER_TEMP:?This script runs on a GitHub-hosted macOS runner}"

SIGNING_DIR=$(mktemp -d "$RUNNER_TEMP/drivemeter-signing.XXXXXX")
KEYCHAIN_PATH="$SIGNING_DIR/signing.keychain-db"
PROFILE_DESTINATION=""
cleanup() {
  security delete-keychain "$KEYCHAIN_PATH" >/dev/null 2>&1 || true
  if [[ -n "$PROFILE_DESTINATION" ]]; then rm -f "$PROFILE_DESTINATION"; fi
  rm -rf "$SIGNING_DIR"
}
trap cleanup EXIT

printf '%s' "$BUILD_CERTIFICATE_BASE64" | base64 --decode > "$SIGNING_DIR/distribution.p12"
printf '%s' "$BUILD_PROVISION_PROFILE_BASE64" | base64 --decode > "$SIGNING_DIR/profile.mobileprovision"
security cms -D -i "$SIGNING_DIR/profile.mobileprovision" > "$SIGNING_DIR/profile.plist"

export SIGNING_DIR
python3 - <<'PY'
import datetime, os, pathlib, plistlib, shlex
folder = pathlib.Path(os.environ['SIGNING_DIR'])
with (folder/'profile.plist').open('rb') as stream:
    profile = plistlib.load(stream)
entitlements = profile['Entitlements']
if not profile.get('ProvisionedDevices') or entitlements.get('get-task-allow', False) or profile.get('ProvisionsAllDevices'):
    raise SystemExit('Use an Ad Hoc distribution profile containing your iPhone UDID, not a development/App Store/enterprise profile.')
if profile['ExpirationDate'] <= datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None):
    raise SystemExit('Provisioning profile has expired')
team = profile['TeamIdentifier'][0]
app_id = entitlements['application-identifier']
bundle_id = app_id.split('.', 1)[1]
if '*' in bundle_id:
    raise SystemExit('Use an explicit App ID for this app')
values = {'TEAM_ID':team, 'BUNDLE_ID':bundle_id, 'PROFILE_UUID':profile['UUID']}
with (folder/'configuration.sh').open('w') as stream:
    for key,value in values.items():
        stream.write(key + '=' + shlex.quote(value) + '\n')
options = {'method':'release-testing','destination':'export','teamID':team,
           'signingStyle':'manual','signingCertificate':'Apple Distribution',
           'provisioningProfiles':{bundle_id:profile['UUID']}}
with (folder/'ExportOptions.plist').open('wb') as stream:
    plistlib.dump(options,stream)
PY
source "$SIGNING_DIR/configuration.sh"

KEYCHAIN_PASSWORD=$(openssl rand -hex 32)
echo "::add-mask::$KEYCHAIN_PASSWORD"
security create-keychain -p "$KEYCHAIN_PASSWORD" "$KEYCHAIN_PATH"
security set-keychain-settings -lut 21600 "$KEYCHAIN_PATH"
security unlock-keychain -p "$KEYCHAIN_PASSWORD" "$KEYCHAIN_PATH"
security import "$SIGNING_DIR/distribution.p12" -P "$P12_PASSWORD" -A -t cert -f pkcs12 -k "$KEYCHAIN_PATH" >/dev/null
security set-key-partition-list -S apple-tool:,apple:,codesign: -s -k "$KEYCHAIN_PASSWORD" "$KEYCHAIN_PATH" >/dev/null
security list-keychains -d user -s "$KEYCHAIN_PATH"
PROFILE_DIRECTORY="$HOME/Library/MobileDevice/Provisioning Profiles"
mkdir -p "$PROFILE_DIRECTORY"
PROFILE_DESTINATION="$PROFILE_DIRECTORY/$PROFILE_UUID.mobileprovision"
cp "$SIGNING_DIR/profile.mobileprovision" "$PROFILE_DESTINATION"

xcodebuild -project DriveMeter.xcodeproj -scheme DriveMeter \
  -configuration Release -destination 'generic/platform=iOS' \
  -archivePath build/Signed.xcarchive \
  CODE_SIGN_STYLE=Manual "DEVELOPMENT_TEAM=$TEAM_ID" \
  "PRODUCT_BUNDLE_IDENTIFIER=$BUNDLE_ID" \
  "PROVISIONING_PROFILE_SPECIFIER=$PROFILE_UUID" \
  'CODE_SIGN_IDENTITY=Apple Distribution' archive
xcodebuild -exportArchive -archivePath build/Signed.xcarchive \
  -exportOptionsPlist "$SIGNING_DIR/ExportOptions.plist" -exportPath build/signed
codesign --verify --deep --strict build/Signed.xcarchive/Products/Applications/DriveMeter.app
test -n "$(find build/signed -maxdepth 1 -name '*.ipa' -print -quit)"
