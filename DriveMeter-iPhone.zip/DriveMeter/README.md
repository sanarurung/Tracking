# 주행 요금계 · iPhone

네이버 지도 SDK 3.24.0 지도, 파란색 GPS 이동 경로, 상단 주행거리·요금을 제공하는 SwiftUI 앱입니다. **iOS 27.0 이상**, iPhone 세로 화면용입니다. 상단의 떠 있는 정보 카드와 하단 컨트롤에 SwiftUI의 네이티브 Liquid Glass를 적용했습니다. 공식 NMapsMap Swift 패키지를 사용하며 Maps의 키 ID가 필요합니다. Xcode 27 이상으로 빌드합니다.

## 실행

1. Mac에서 `DriveMeter.xcodeproj`를 Xcode로 엽니다.
2. 네이버 클라우드 Maps에서 Dynamic Map을 활성화하고 앱의 iOS Bundle ID를 등록합니다. Xcode의 사용자 정의 빌드 설정 `NAVER_MAPS_CLIENT_ID`에 키 ID를 입력합니다. Client Secret은 필요하지 않습니다.
3. 프로젝트 → DriveMeter 타깃 → Signing & Capabilities에서 본인의 Team을 선택합니다. Bundle Identifier `com.example.DriveMeter`는 고유한 값으로 변경합니다.
3. 연결한 iPhone을 실행 대상으로 선택하고 Run을 누릅니다. 요청되면 iPhone 개발자 모드를 활성화합니다.
4. 앱에서 **주행 시작**을 누르고 위치 접근을 허용합니다. **정확한 위치**를 켭니다.

Windows에서는 이 iOS 앱을 직접 빌드할 수 없습니다. 본인 소유의 Mac 외에 GitHub Actions의 macOS 러너로 빌드할 수 있습니다. [클라우드 빌드 안내](CLOUD-BUILD.md)를 참고하세요. 이 폴더는 소스 프로젝트이며 빌드 전에는 설치용 IPA가 없습니다.

## 요금 규칙

사용자가 선택한 **구간별 누진 계산**입니다.

| 거리 구간 | 단가 |
| --- | --- |
| 0~30km | 270원/km |
| 30km 초과~100km | 250원/km |
| 100km 초과 | 220원/km |

기본요금과 최소요금 없이 첫 이동부터 계산합니다. 1km 미만도 비례 계산하고 전체 금액을 원 단위로 반올림합니다. 예: 50km = 30×270 + 20×250 = **13,100원**, 120km = **30,000원**.

## 기록 방식

- **주행 시작 / 일시정지 / 재개 / 종료 / 새 주행**을 지원합니다. 종료·초기화는 확인 후 실행합니다.
- GPS가 정상일 때부터 가속도계·자이로의 이동 예측과 GPS 좌표 사이 거리를 결합합니다. GPS 속도 정확도로 예측 속도를 보정하고, 신뢰할 수 있는 직진 구간에서는 센서 편향을 천천히 보정합니다. 도로 경로 검색이나 차량 계기판 데이터를 사용하지 않습니다.
- 수평 오차 30m 초과, 오래된 좌표, 시속 252km를 넘는 위치 점프를 제외합니다. 작은 이동과 정차 중 GPS 흔들림도 필터링합니다. 필터로 인해 느린 이동이나 짧은 구간이 적게 집계될 수 있습니다.
- 일시정지와 재개 사이를 연결하지 않습니다. GPS가 약 5초 이상 끊기면 가속도계·자이로 기반 추정으로 전환합니다. 마지막 GPS 속도와 진행방향을 기준으로 중력을 제외한 가속도를 진행방향에 투영해 적분합니다.
- 음영 구간당 **최대 3분(180초)** 추정합니다. 전환 대기 5초도 센서 샘플이 이어졌다면 포함합니다. 센서가 0.5초 넘게 끊기거나 추정 한도를 넘기면 GPS 복귀까지 적립을 멈춥니다. GPS 속도·방향 기준점이 없거나 모션 센서·진북 기준 좌표계가 지원되지 않거나 방향 센서가 보정되지 않았으면 추정하지 않습니다.
- 센서 추정 거리와 그에 따른 요금은 총계에 포함되며, 상단에 추정 누적 거리를 별도로 표시합니다. GPS 복귀 시 추정값을 유지하고 GPS 위치 사이 직선거리를 다시 더하지 않습니다. 지도에는 GPS 실측 경로만 파란색으로 그리며, 음영 구간은 끊겨 보입니다.
- 휴대폰을 거치대에 고정해야 합니다. 센서 편향·차량 회전·자기장 때문에 추정 오차가 누적됩니다. 3분 추정값을 실측과 동일한 정확도로 보장하지 않습니다. GPS 복귀 후 추정 구간을 소급 보정하지는 않습니다.
- 주행 중 배경 위치 업데이트를 사용하도록 설정했습니다. 화면 잠금 시 작동 여부는 실제 iPhone에서 검증해야 합니다. 앱 강제 종료 후에는 기록하지 않습니다.
- 진행 중인 주행은 기기 내부 JSON으로 복원용 저장합니다. 종료하면 날짜·거리·최종 요금·경로와 센서 보정/추정 구간을 `Documents/Trips/<UUID>.json`에 자동 보관합니다. 파일은 원자적으로 저장하며, 재시도해도 같은 주행이 중복 저장되지 않습니다.
- 상단 **기록**에서 과거 주행을 선택해 요금과 Apple 지도 경로를 다시 봅니다. **새 주행은 과거 기록을 지우지 않습니다.** 보관에 실패하면 현재 기록을 유지하고 재시도 후 새 주행으로 넘어갑니다. 이전 버전의 마지막 완료 기록도 자동 이관합니다. 이전 파일에 시각이 없으면 임의로 주행 시각을 만들지 않습니다.
- 앱 재실행 시 진행 중이던 주행은 **일시정지**로 복원하고 새 GPS 기준점에서 재개합니다. 앱 삭제나 기기 데이터 손실에 대비한 서버·클라우드 백업 기능은 없습니다.
- 정상 GPS 구간의 센서 보정도 정확도 향상을 보장하지 않습니다. 위치 점프·정차 흔들림 억제와 중복 계산 방지는 합성 입력으로 검사하며, 실제 개선 여부는 고정 거치한 iPhone에서 GPS 단독·차량 계기판과 비교해야 합니다. Apple Core Location 자체도 여러 기기 신호를 결합한 위치 서비스입니다.
- 별도 계정·분석 SDK·서버 업로드는 없습니다. 지도 표시는 Apple MapKit 서비스를 사용합니다.

## 검증 상태와 Mac에서의 테스트

최신 컴파일·테스트 결과는 [GitHub Actions](https://github.com/sanarurung/Tracking/actions)에서 확인할 수 있습니다. 코어 테스트는 `swift test --parallel`로 macOS에서 실행해 시뮬레이터 시작 지연을 피하고, 앱은 iPhoneOS 27 SDK로 별도 아카이브합니다. 저장·재시도·손상 파일 보존·이전 기록 이관, 정상 GPS 센서 융합·정차·위치 점프·센서 단절·180초 한도를 검사합니다. 실기기 주행 정확도는 아직 검증하지 않았습니다. 화면 캡처는 사용자의 요청에 따라 제외했습니다. 배포 전 아래 항목을 확인하세요.

1. Xcode에서 Product → Test (`⌘U`)로 누진 요금 경계, 소수 거리, 원 단위 반올림과 센서 추정 180초 한도·재개·가감속 테스트를 실행합니다.
2. 시뮬레이터 Features → Location 또는 Xcode GPX 시뮬레이션으로 거리와 파란 경로가 함께 증가하는지 확인합니다.
3. iPhone에서 시작 후 짧은 구간을 이동하고 위치·거리·요금을 확인합니다. 운전 중 조작은 동승자가 수행합니다.
4. 일시정지 중 이동한 뒤 재개하고, 중간 구간이 거리와 선에 포함되지 않는지 확인합니다.
5. 주행 중 화면을 잠그고 이동한 뒤 기록이 이어지는지 확인합니다.
6. 종료 후 재실행하여 거리·요금·선이 복원되는지, 진행 중 강제 종료 후에는 일시정지로 복원되는지 확인합니다.
7. 위치 거부·위치 서비스 끄기·정확한 위치 끄기·GPS 수신 불량에서 상태 안내와 복구를 확인합니다.
8. 큰 글자 설정에서 상단 숫자·버튼 표시와 VoiceOver를 확인합니다.
9. 실기기에서 GPS 기준점을 얻은 뒤 음영 구간에 진입하여 센서 추정 표시와 요금 증가를 확인합니다. 180초 이후 정지와 GPS 복귀 후 중복 적립 방지도 확인합니다. 화면 잠금·백그라운드의 센서 수신은 별도로 확인해야 합니다.

시뮬레이터 이름은 `xcodebuild -showdestinations -scheme DriveMeter`로 확인할 수 있습니다.

```sh
xcodebuild -project DriveMeter.xcodeproj -scheme DriveMeter \
  -destination 'platform=iOS Simulator,name=<설치된 iPhone 시뮬레이터 이름>' test
```

## Apple 문서

- [Xcode 요구사항](https://developer.apple.com/xcode/system-requirements)
- [MapPolyline](https://developer.apple.com/documentation/mapkit/mappolyline)
- [배경 위치 업데이트 설정](https://developer.apple.com/documentation/corelocation/cllocationmanager/allowsbackgroundlocationupdates)
- [앱 테스트 및 배포](https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases/)
- [Core Motion 센서 처리](https://developer.apple.com/documentation/coremotion/getting-processed-device-motion-data)
