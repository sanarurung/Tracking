# 주행 요금계 · iPhone

Apple MapKit 지도, 파란색 GPS 이동 경로, 상단 주행거리·요금을 제공하는 SwiftUI 앱입니다. **iOS 27.0 이상**, iPhone 세로 화면용입니다. 상단의 떠 있는 정보 카드와 하단 컨트롤에 SwiftUI의 네이티브 Liquid Glass를 적용했습니다. 외부 패키지와 지도 API 키가 필요하지 않습니다. Xcode 27 이상으로 빌드합니다.

## 실행

1. Mac에서 `DriveMeter.xcodeproj`를 Xcode로 엽니다.
2. 프로젝트 → DriveMeter 타깃 → Signing & Capabilities에서 본인의 Team을 선택합니다. Bundle Identifier `com.example.DriveMeter`는 고유한 값으로 변경합니다.
3. 연결한 iPhone을 실행 대상으로 선택하고 Run을 누릅니다. 요청되면 iPhone 개발자 모드를 활성화합니다.
4. 앱에서 **주행 시작**을 누르고 위치 접근을 허용합니다. **정확한 위치**를 켭니다.

Windows에서는 이 iOS 앱을 직접 빌드할 수 없습니다. 본인 소유의 Mac 외에 GitHub Actions의 macOS 러너로 빌드할 수 있습니다. [클라우드 빌드 안내](CLOUD-BUILD.md)를 참고하세요. 이 폴더는 소스 프로젝트이며 빌드 전에는 설치용 IPA가 없습니다.

## 요금 규칙

사용자가 선택한 **구간별 누진 계산**입니다.

| 거리 구간 | 단가 |
| --- | --- |
| 0~30km | 270원/km |
| 30km 초과~100km | 250원/km |
| 100km 초과 | 220원/km |

기본요금과 최소요금 없이 첫 이동부터 계산합니다. 1km 미만도 비례 계산하고 전체 금액을 원 단위로 반올림합니다. 예: 50km = 30×270 + 20×250 = **13,100원**, 120km = **30,000원**.

## 기록 방식

- **주행 시작 / 일시정지 / 재개 / 종료 / 새 주행**을 지원합니다. 종료·초기화는 확인 후 실행합니다.
- 위치 갱신을 받아 좌표 사이 거리를 누적합니다. 도로 경로 검색이나 차량 계기판 데이터를 사용하지 않습니다.
- 수평 오차 30m 초과, 오래된 좌표, 시속 252km를 넘는 위치 점프를 제외합니다. 작은 이동과 정차 중 GPS 흔들림도 필터링합니다. 필터로 인해 느린 이동이나 짧은 구간이 적게 집계될 수 있습니다.
- 일시정지와 재개 사이를 연결하지 않습니다. GPS가 약 5초 이상 끊기면 가속도계·자이로 기반 추정으로 전환합니다. 마지막 GPS 속도와 진행방향을 기준으로 중력을 제외한 가속도를 진행방향에 투영해 적분합니다.
- 음영 구간당 **최대 3분(180초)** 추정합니다. 전환 대기 5초도 센서 샘플이 이어졌다면 포함합니다. 센서가 0.5초 넘게 끊기거나 추정 한도를 넘기면 GPS 복귀까지 적립을 멈춥니다. GPS 속도·방향 기준점이 없거나 모션 센서·진북 기준 좌표계가 지원되지 않거나 방향 센서가 보정되지 않았으면 추정하지 않습니다.
- 센서 추정 거리와 그에 따른 요금은 총계에 포함되며, 상단에 추정 누적 거리를 별도로 표시합니다. GPS 복귀 시 추정값을 유지하고 GPS 위치 사이 직선거리를 다시 더하지 않습니다. 지도에는 GPS 실측 경로만 파란색으로 그리며, 음영 구간은 끊겨 보입니다.
- 휴대폰을 거치대에 고정해야 합니다. 센서 편향·차량 회전·자기장 때문에 추정 오차가 누적됩니다. 3분 추정값을 실측과 동일한 정확도로 보장하지 않습니다. GPS 복귀 후 추정 구간을 소급 보정하지는 않습니다.
- 주행 중 배경 위치 업데이트를 사용하도록 설정했습니다. 화면 잠금 시 작동 여부는 실제 iPhone에서 검증해야 합니다. 앱 강제 종료 후에는 기록하지 않습니다.
- 현재 주행 한 건을 기기 내부 JSON으로 저장합니다. 유효 위치 수신 시 최대 약 5초 간격, 일시정지·종료·화면 전환 시 저장합니다. 예기치 않은 종료 시 아직 저장하지 못한 기록은 유실될 수 있습니다.
- 앱 재실행 시 진행 중이던 주행은 **일시정지**로 복원하고 새 GPS 기준점에서 재개합니다. 새 주행은 기존 기록을 지웁니다. 과거 여러 건의 기록 목록은 없습니다.
- 별도 계정·분석 SDK·서버 업로드는 없습니다. 지도 표시는 Apple MapKit 서비스를 사용합니다.

## 검증 상태와 Mac에서의 테스트

이 프로젝트는 Windows에서 작성했습니다. 프로젝트 참조·설정·plist·공유 스킴은 정적으로 검사했으며, **Swift 컴파일, XCTest 실행, 시뮬레이터 및 실기기 검증은 수행하지 못했습니다**. 배포 전 아래 항목을 확인하세요.

1. Xcode에서 Product → Test (`⌘U`)로 누진 요금 경계, 소수 거리, 원 단위 반올림과 센서 추정 180초 한도·재개·가감속 테스트를 실행합니다.
2. 시뮬레이터 Features → Location 또는 Xcode GPX 시뮬레이션으로 거리와 파란 경로가 함께 증가하는지 확인합니다.
3. iPhone에서 시작 후 짧은 구간을 이동하고 위치·거리·요금을 확인합니다. 운전 중 조작은 동승자가 수행합니다.
4. 일시정지 중 이동한 뒤 재개하고, 중간 구간이 거리와 선에 포함되지 않는지 확인합니다.
5. 주행 중 화면을 잠그고 이동한 뒤 기록이 이어지는지 확인합니다.
6. 종료 후 재실행하여 거리·요금·선이 복원되는지, 진행 중 강제 종료 후에는 일시정지로 복원되는지 확인합니다.
7. 위치 거부·위치 서비스 끄기·정확한 위치 끄기·GPS 수신 불량에서 상태 안내와 복구를 확인합니다.
8. 큰 글자 설정에서 상단 숫자·버튼 표시와 VoiceOver를 확인합니다.
9. 실기기에서 GPS 기준점을 얻은 뒤 음영 구간에 진입하여 센서 추정 표시와 요금 증가를 확인합니다. 180초 이후 정지와 GPS 복귀 후 중복 적립 방지도 확인합니다. 화면 잠금·백그라운드의 센서 수신은 별도로 확인해야 합니다.

시뮬레이터 이름은 `xcodebuild -showdestinations -scheme DriveMeter`로 확인할 수 있습니다.

```sh
xcodebuild -project DriveMeter.xcodeproj -scheme DriveMeter \
  -destination 'platform=iOS Simulator,name=<설치된 iPhone 시뮬레이터 이름>' test
```

## Apple 문서

- [Xcode 요구사항](https://developer.apple.com/xcode/system-requirements)
- [MapPolyline](https://developer.apple.com/documentation/mapkit/mappolyline)
- [배경 위치 업데이트 설정](https://developer.apple.com/documentation/corelocation/cllocationmanager/allowsbackgroundlocationupdates)
- [앱 테스트 및 배포](https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases/)
- [Core Motion 센서 처리](https://developer.apple.com/documentation/coremotion/getting-processed-device-motion-data)
