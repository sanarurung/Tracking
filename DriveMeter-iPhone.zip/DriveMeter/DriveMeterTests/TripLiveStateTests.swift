import XCTest
@testable import DriveMeter

final class TripLiveStateTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_800_000_000)
    private func state(_ phase: TripLiveState.Phase = .recording, meters: Double = 1250,
                       speed: Double? = 72.4, expiry: Double = 1) -> TripLiveState {
        TripLiveState(phase: phase, meters: meters, fareWon: 338, speedKmh: speed,
                      speedValidUntil: now.addingTimeInterval(expiry), now: now)
    }
    func testRecordingShowsSpeedAndDistance() {
        let s = state()
        XCTAssertEqual(s.speedText(at: now, stale: false), "72")
        XCTAssertEqual(s.distanceText, "1.25")
    }
    func testStaleSpeedIsHiddenButDistancePreserved() {
        let s = state()
        XCTAssertEqual(s.speedText(at: now, stale: true), "—")
        XCTAssertEqual(s.speedText(at: now.addingTimeInterval(1), stale: false), "—")
        XCTAssertEqual(s.meters, 1250)
    }
    func testPauseAndFinishHideSpeed() {
        for phase in [TripLiveState.Phase.paused, .finished] {
            XCTAssertNil(state(phase).speedKmh)
            XCTAssertEqual(state(phase).fareWon, 338)
        }
    }
    func testInvalidSpeedCannotAppear() {
        for speed in [Double.nan, .infinity, -1, 253] { XCTAssertNil(state(speed: speed).speedKmh) }
        XCTAssertNil(state(speed: nil).speedKmh)
        XCTAssertNil(state(expiry: 0).speedKmh)
    }
    func testZeroSpeedIsValid() { XCTAssertEqual(state(speed: 0).speedText(at: now, stale: false), "0") }
    func testDistanceSanitizationAndCompactWidths() {
        XCTAssertEqual(state(meters: .nan).distanceText, "0.00")
        XCTAssertEqual(state(meters: -12).meters, 0)
        XCTAssertEqual(state(meters: 50_500).compactDistanceText, "50.5")
        XCTAssertEqual(state(meters: 150_500).compactDistanceText, "150")
    }
    func testContentRoundTripsWithoutLocation() throws {
        let s = state()
        let data = try JSONEncoder().encode(s)
        XCTAssertEqual(try JSONDecoder().decode(TripLiveState.self, from: data), s)
        XCTAssertFalse(String(decoding: data, as: UTF8.self).contains("latitude"))
    }
}
