import XCTest
@testable import DriveMeter

final class SpeedFusionTests: XCTestCase {
    func testNoSensorSpeedWithoutAnInitialGPSReference() {
        var engine=SpeedFusion()
        sample(&engine,from:0.05,through:6,acceleration:1)
        XCTAssertNil(engine.reading(at:6))
    }
    func testMotionPredictsSpeedBetweenHealthyGPSFixes() {
        var engine=seed()
        sample(&engine,from:0.05,through:1,acceleration:1)
        XCTAssertGreaterThan(engine.reading(at:1)!.metresPerSecond,10.4)
        XCTAssertEqual(engine.reading(at:1)!.source,.gpsMotion)
        engine.observeGPS(speed:10,speedAccuracy:1,course:0,horizontalAccuracy:5,at:1.01,motionAvailable:true)
        XCTAssertGreaterThan(engine.reading(at:1.01)!.metresPerSecond,10)
        XCTAssertLessThan(engine.reading(at:1.01)!.metresPerSecond,11)
    }
    func testGPSOutageUsesMotionAndMarksItAsEstimated() {
        var engine=seed()
        sample(&engine,from:0.05,through:6,acceleration:0.5)
        XCTAssertEqual(engine.reading(at:6)!.source,.inertial)
        XCTAssertGreaterThan(engine.reading(at:6)!.metresPerSecond,12)
    }
    func testUnknownOrInaccurateGPSCannotOverwriteSensorPrediction() {
        var engine=seed()
        sample(&engine,from:0.05,through:6,acceleration:0)
        engine.observeGPS(speed:-1,speedAccuracy:-1,course:-1,horizontalAccuracy:100,at:6,motionAvailable:true)
        XCTAssertEqual(engine.reading(at:6)!.source,.inertial)
        XCTAssertEqual(engine.reading(at:6)!.metresPerSecond,10,accuracy:0.001)
    }
    func testThreeMinuteLimitRequiresGPSRecovery() {
        var engine=seed()
        sample(&engine,from:0.05,through:180,acceleration:0)
        XCTAssertNotNil(engine.reading(at:180))
        engine.sample(north:0,west:0,at:180.1,sensorTime:180.1)
        XCTAssertNil(engine.reading(at:180.1))
        engine.observeGPS(speed:8,speedAccuracy:0.5,course:0,horizontalAccuracy:5,at:181,motionAvailable:true)
        XCTAssertEqual(engine.reading(at:181)!.metresPerSecond,8,accuracy:0.001)
    }
    func testMotionInterruptionNeverKeepsAnOutageSpeedAlive() {
        var engine=seed()
        sample(&engine,from:0.05,through:6,acceleration:0)
        engine.sample(north:0,west:0,at:7,sensorTime:7)
        XCTAssertNil(engine.reading(at:7))
    }
    func testUnavailableMotionFallsBackToFreshGPSOnly() {
        var engine=SpeedFusion()
        engine.observeGPS(speed:8,speedAccuracy:0.5,course:0,horizontalAccuracy:5,at:0,motionAvailable:false)
        XCTAssertEqual(engine.reading(at:1)?.source,.gps)
        XCTAssertNil(engine.reading(at:6))
    }
    func testBrakingCannotDisplayNegativeSpeed() {
        var engine=seed()
        sample(&engine,from:0.05,through:6,acceleration:-4)
        XCTAssertEqual(engine.reading(at:6)!.metresPerSecond,0)
    }
    private func seed()->SpeedFusion {
        var engine=SpeedFusion()
        engine.observeGPS(speed:10,speedAccuracy:1,course:0,horizontalAccuracy:5,at:0,motionAvailable:true)
        engine.sample(north:0,west:0,at:0,sensorTime:0)
        return engine
    }
    private func sample(_ engine:inout SpeedFusion,from start:Double,through end:Double,acceleration:Double) {
        for tick in Int((start*20).rounded())...Int((end*20).rounded()) {
            let time=Double(tick)/20
            engine.sample(north:acceleration,west:0,at:time,sensorTime:time)
        }
    }
}
