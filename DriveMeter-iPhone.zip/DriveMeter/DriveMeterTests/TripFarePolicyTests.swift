import XCTest
@testable import DriveMeter

final class TripFarePolicyTests: XCTestCase {
    let policy = TripFarePolicy(mode: .socar, wonPerKm: 200)
    func testFirstThirtyKilometresAreFree() {
        for meters in [0.0, 1, 29_999, 30_000] { XCTAssertEqual(policy.won(meters: meters), 0) }
    }
    func testOnlyExcessDistanceIsBilled() {
        XCTAssertEqual(policy.won(meters: 50_000), 4_000)
        XCTAssertEqual(policy.won(meters: 30_500), 100)
    }
    func testRateDoesNotChangeAtOtherDistanceBands() {
        XCTAssertEqual(policy.won(meters: 100_000), 14_000)
        XCTAssertEqual(policy.won(meters: 120_000), 18_000)
    }
    func testElectricVehicleZeroRate() {
        let electric = TripFarePolicy(mode: .socar, wonPerKm: 0)
        XCTAssertEqual(electric.won(meters: 500_000), 0)
        XCTAssertEqual(TripFarePolicy.parseRate("0"), 0)
    }
    func testInvalidInputsAreRejected() {
        for input in ["", "-1", "1.5", "abc", "9999999999999999999999999999"] {
            XCTAssertNil(TripFarePolicy.parseRate(input))
        }
        XCTAssertEqual(TripFarePolicy.parseRate(" 200 "), 200)
        XCTAssertEqual(policy.won(meters: .nan), 0)
        XCTAssertEqual(policy.won(meters: -100), 0)
    }
    func testGcarKeepsExistingProgressiveFare() {
        XCTAssertEqual(TripFarePolicy.gcar.won(meters: 50_000), 13_100)
        XCTAssertEqual(TripFarePolicy.gcar.won(meters: 120_000), 30_000)
    }
    func testSnapshotRestoresSocarRate() throws {
        let snapshot = TripSnapshot(meters: 50_000, segments: [], finished: false, farePolicy: policy)
        let restored = try JSONDecoder().decode(TripSnapshot.self, from: JSONEncoder().encode(snapshot))
        XCTAssertEqual(restored.farePolicy, policy)
        XCTAssertEqual(restored.farePolicy?.won(meters: restored.meters), 4_000)
    }
    func testLegacySnapshotDefaultsToGcar() throws {
        let data = Data(#"{"meters":50000,"segments":[],"finished":false}"#.utf8)
        let restored = try JSONDecoder().decode(TripSnapshot.self, from: data)
        XCTAssertNil(restored.farePolicy)
        XCTAssertEqual((restored.farePolicy ?? .gcar).won(meters: restored.meters), 13_100)
    }
    func testHistoryRetainsRateAndFinalAmount() throws {
        let record = TripRecord(id: UUID(), startedAt: nil, endedAt: nil, savedAt: Date(),
            meters: 50_000, estimatedMeters: 0, fusedMeters: 0, fareWon: 4_000, segments: [],
            calculationVersion: "socar-fixed-30free-v1", farePolicy: policy)
        let restored = try JSONDecoder().decode(TripRecord.self, from: JSONEncoder().encode(record))
        XCTAssertTrue(restored.isValid)
        XCTAssertEqual(restored.farePolicy, policy)
        XCTAssertEqual(restored.fareWon, 4_000)
    }
}
