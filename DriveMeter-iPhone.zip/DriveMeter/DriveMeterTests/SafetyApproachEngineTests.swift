import XCTest
import CoreLocation
@testable import DriveMeter

final class SafetyApproachEngineTests: XCTestCase {
    let now = Date(timeIntervalSince1970: 1_000)
    func testExactSeventyUsesFiveHundredMetresAndAboveUsesOneKilometre() {
        XCTAssertEqual(SafetyApproachEngine.range(metresPerSecond: 70/3.6),500)
        XCTAssertEqual(SafetyApproachEngine.range(metresPerSecond: 70.01/3.6),1_000)
    }
    func testLowSpeedAlertsOnlyInsideFiveHundred() {
        var e=SafetyApproachEngine()
        XCTAssertNil(e.update(location:fix(speed:60),points:[point("far",north:600)],now:now).warning)
        XCTAssertNotNil(e.update(location:fix(speed:60),points:[point("near",north:490)],now:now).announcement)
    }
    func testHighSpeedAlertsWithinOneKilometre() {
        var e=SafetyApproachEngine()
        XCTAssertNotNil(e.update(location:fix(speed:71),points:[point("far",north:990)],now:now).announcement)
        XCTAssertNil(e.update(location:fix(speed:71),points:[point("outside",north:1_010)],now:now).warning)
    }
    func testRearAndSideRoadAreExcluded() {
        var e=SafetyApproachEngine()
        XCTAssertNil(e.update(location:fix(speed:60),points:[point("rear",north:-100),point("side",north:200,east:60)],now:now).warning)
    }
    func testNearestForwardPointSelectedWithoutTapAndDoesNotRepeat() {
        var e=SafetyApproachEngine();let p=[point("a",north:150),point("b",north:400)]
        XCTAssertEqual(e.update(location:fix(speed:60),points:p,now:now).announcement?.point.id,"a")
        XCTAssertNil(e.update(location:fix(speed:60,date:now.addingTimeInterval(10)),points:p,now:now.addingTimeInterval(10)).announcement)
    }
    func testStationaryUnknownCourseAndStaleFixDoNotAlert() {
        for location in [fix(speed:0),fix(speed:60,course:-1),fix(speed:60,date:now.addingTimeInterval(-6))] {
            var e=SafetyApproachEngine()
            XCTAssertNil(e.update(location:location,points:[point("p",north:100)],now:now).announcement)
        }
    }
    func testPoorGPSAccuracyDoesNotAlertAndWarningExpires() {
        var e=SafetyApproachEngine()
        XCTAssertNil(e.update(location:fix(speed:60,accuracy:80),points:[point("p",north:100)],now:now).warning)
        let warning=e.update(location:fix(speed:60),points:[point("p",north:100)],now:now).warning!
        XCTAssertTrue(warning.isFresh(at:now.addingTimeInterval(5)))
        XCTAssertFalse(warning.isFresh(at:now.addingTimeInterval(6)))
    }
    func testHeadingWrapAroundNorth() {
        var e=SafetyApproachEngine()
        XCTAssertNotNil(e.update(location:fix(speed:60,course:359),points:[point("p",north:300)],now:now).warning)
    }
    private func fix(speed:Double,course:Double=0,accuracy:Double=5,date:Date?=nil)->CLLocation {
        CLLocation(coordinate:CLLocationCoordinate2D(latitude:37,longitude:127),altitude:0,horizontalAccuracy:accuracy,
                   verticalAccuracy:5,course:course,courseAccuracy:5,speed:speed/3.6,speedAccuracy:0.5,timestamp:date ?? now)
    }
    private func point(_ id:String,north:Double,east:Double=0)->SafetyPoint {
        SafetyPoint(id:id,kind:.camera,latitude:37+north/111195,longitude:127+east/(111195*cos(37 * .pi/180)),speedLimit:50,referenceDate:"")
    }
}
