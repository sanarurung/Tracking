import XCTest
@testable import DriveMeter

final class FareCalculatorTests: XCTestCase {
    func testTierBoundariesAndExamples() {
        let cases: [(Double, Int)] = [
            (0, 0), (1_000, 270), (30_000, 8_100),
            (50_000, 13_100), (100_000, 25_600), (120_000, 30_000)
        ]
        for (meters, expected) in cases {
            XCTAssertEqual(FareCalculator.won(meters: meters), expected, "meters=\(meters)")
        }
    }

    func testPartialKilometresAndWonRounding() {
        XCTAssertEqual(FareCalculator.won(meters: 500), 135)
        XCTAssertEqual(FareCalculator.won(meters: 1_500), 405)
        XCTAssertEqual(FareCalculator.won(meters: 30_500), 8_225)
        XCTAssertEqual(FareCalculator.won(meters: 100_500), 25_710)
        XCTAssertEqual(FareCalculator.won(meters: 10), 3)
    }

    func testInvalidDistanceDoesNotProduceFare() {
        for value in [-1.0, Double.nan, Double.infinity, -Double.infinity] {
            XCTAssertEqual(FareCalculator.won(meters: value), 0)
        }
    }
}
