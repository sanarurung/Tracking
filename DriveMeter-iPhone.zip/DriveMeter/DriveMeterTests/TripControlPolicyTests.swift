import XCTest
@testable import DriveMeter

final class TripControlPolicyTests: XCTestCase {
    private let id = UUID()
    func testRecordingAcceptsPauseAndFinish() {
        XCTAssertTrue(TripControlPolicy.accepted(.pause, requestedID: id.uuidString, currentID: id, phase: .recording))
        XCTAssertTrue(TripControlPolicy.accepted(.finish, requestedID: id.uuidString, currentID: id, phase: .recording))
        XCTAssertFalse(TripControlPolicy.accepted(.resume, requestedID: id.uuidString, currentID: id, phase: .recording))
    }
    func testPausedAcceptsResumeAndFinish() {
        XCTAssertTrue(TripControlPolicy.accepted(.resume, requestedID: id.uuidString, currentID: id, phase: .paused))
        XCTAssertTrue(TripControlPolicy.accepted(.finish, requestedID: id.uuidString, currentID: id, phase: .paused))
        XCTAssertFalse(TripControlPolicy.accepted(.pause, requestedID: id.uuidString, currentID: id, phase: .paused))
    }
    func testOldTripCannotControlCurrentTrip() {
        for command in [TripControlCommand.pause, .resume, .finish] {
            XCTAssertFalse(TripControlPolicy.accepted(command, requestedID: UUID().uuidString, currentID: id, phase: .recording))
        }
    }
    func testFinishedAndReadyRejectAllCommands() {
        let phases: [TripLiveState.Phase?] = [.finished, nil]
        for phase in phases {
            for command in [TripControlCommand.pause, .resume, .finish] {
                XCTAssertFalse(TripControlPolicy.accepted(command, requestedID: id.uuidString, currentID: id, phase: phase))
            }
        }
    }
    func testMalformedIDIsRejected() {
        XCTAssertFalse(TripControlPolicy.accepted(.finish, requestedID: "invalid", currentID: id, phase: .recording))
    }
}
