import XCTest
@testable import DriveMeter

final class SpeedReadingTests: XCTestCase {
    let now = Date(timeIntervalSince1970: 1_000)

    func testSensorReadingsExpirePromptlyAfterSamplesStop() {
        let speed = SpeedReading(metresPerSecond:10,accuracy:8,timestamp:now,source:.inertial)
        XCTAssertEqual(speed.kilometresPerHour(at:now),36)
        XCTAssertNil(speed.kilometresPerHour(at:now.addingTimeInterval(1.01)))
    }

    func testCachedSensorReadingCannotOutliveTheOutageLimit() {
        let speed = SpeedReading(metresPerSecond:10,accuracy:8,timestamp:now,source:.inertial,expiresAt:now.addingTimeInterval(0.1))
        XCTAssertNil(speed.kilometresPerHour(at:now.addingTimeInterval(0.11)))
    }

    func testGPSMetresPerSecondConvertsToKilometresPerHour() {
        XCTAssertEqual(reading(20).kilometresPerHour(at: now), 72)
    }

    func testValidStationarySpeedRemainsZero() {
        XCTAssertEqual(reading(0).kilometresPerHour(at: now), 0)
    }

    func testUnknownInaccurateAndNonfiniteSpeedDoNotLookStationary() {
        for speed in [-1.0, Double.nan, Double.infinity, 71] {
            XCTAssertNil(reading(speed).kilometresPerHour(at: now))
        }
        for accuracy in [-1.0, 5.1, Double.nan] {
            XCTAssertNil(reading(10, accuracy: accuracy).kilometresPerHour(at: now))
        }
    }

    func testExpiredAndFutureReadingsAreNotShown() {
        let speed = reading(20)
        XCTAssertEqual(speed.kilometresPerHour(at: now.addingTimeInterval(5)), 72)
        XCTAssertNil(speed.kilometresPerHour(at: now.addingTimeInterval(5.01)))
        XCTAssertNil(speed.kilometresPerHour(at: now.addingTimeInterval(-2)))
    }

    private func reading(_ speed: Double, accuracy: Double = 0.5) -> SpeedReading {
        SpeedReading(metresPerSecond: speed, accuracy: accuracy, timestamp: now)
    }
}
