import XCTest
@testable import DriveMeter

final class TripHistoryTests: XCTestCase {
    private func record(id: UUID = UUID(), meters: Double = 50_000) -> TripRecord {
        TripRecord(id: id, startedAt: Date(timeIntervalSince1970: 100), endedAt: Date(timeIntervalSince1970: 200),
                   savedAt: Date(timeIntervalSince1970: 201), meters: meters, estimatedMeters: 50,
                   fusedMeters: 100, fareWon: 13_100,
                   segments: [[RoutePoint(latitude: 37.5, longitude: 127), RoutePoint(latitude: 37.6, longitude: 127.1)]],
                   calculationVersion: "gps-motion-v2")
    }

    func testMultipleTripsAndRoutesSurviveAStoreReopen() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = TripHistoryStore(directory: directory)
        let first = record(), second = record()
        try store.save(first)
        try store.save(second)
        let reopened = try TripHistoryStore(directory: directory).load()
        XCTAssertEqual(Set(reopened.records.map(\.id)), Set([first.id, second.id]))
        XCTAssertEqual(reopened.records.first?.segments.first?.count, 2)
        XCTAssertEqual(reopened.records.first?.fareWon, 13_100)
    }

    func testRetryingTheSameTripDoesNotDuplicateIt() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = TripHistoryStore(directory: directory)
        let trip = record()
        try store.save(trip)
        try store.save(trip)
        XCTAssertEqual(try store.load().records.count, 1)
    }

    func testCorruptRecordIsPreservedAndDoesNotHideGoodRecords() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = TripHistoryStore(directory: directory)
        try store.save(record())
        let corrupt = directory.appendingPathComponent("corrupt.json")
        try Data("broken".utf8).write(to: corrupt)
        let loaded = try store.load()
        XCTAssertEqual(loaded.records.count, 1)
        XCTAssertEqual(loaded.unreadable, 1)
        XCTAssertEqual(try String(contentsOf: corrupt), "broken")
    }

    func testFailedWriteDoesNotEraseTheExistingTrip() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = TripHistoryStore(directory: directory)
        let valid = record()
        try store.save(valid)
        XCTAssertThrowsError(try store.save(record(id: valid.id, meters: .nan)))
        XCTAssertEqual(try store.load().records.first?.meters, valid.meters)
    }

    func testLegacyCompletedSnapshotHasAStableMigrationID() throws {
        let data = Data("{\"meters\":50000,\"segments\":[],\"finished\":true,\"estimatedMeters\":0}".utf8)
        let first = try JSONDecoder().decode(TripSnapshot.self, from: data)
        let second = try JSONDecoder().decode(TripSnapshot.self, from: data)
        XCTAssertNil(first.startedAt)
        XCTAssertEqual(TripHistoryStore.legacyID(for: first), TripHistoryStore.legacyID(for: second))
    }

    func testPathCollisionIsReportedAsASaveFailure() throws {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: file) }
        try Data("existing".utf8).write(to: file)
        XCTAssertThrowsError(try TripHistoryStore(directory: file).save(record()))
        XCTAssertEqual(try String(contentsOf: file), "existing")
    }
}
