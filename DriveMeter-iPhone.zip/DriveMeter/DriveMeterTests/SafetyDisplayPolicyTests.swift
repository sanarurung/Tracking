import XCTest
@testable import DriveMeter

final class SafetyDisplayPolicyTests: XCTestCase {
    func testZoomedOutMapDoesNotShowSafetyMarkers() {
        XCTAssertTrue(visible([candidate("a",100,100)],zoom:13.9).isEmpty)
    }
    func testBumpsAppearOnlyAtDetailedZoom() {
        let bump=candidate("b",100,100,kind:.bump)
        XCTAssertTrue(visible([bump],zoom:15).isEmpty)
        XCTAssertEqual(visible([bump],zoom:16).count,1)
    }
    func testOverlappingSignsCollapseAndSelectedSignWins() {
        let candidates=[candidate("a",100,100),candidate("b",110,110),candidate("c",200,100)]
        XCTAssertEqual(visible(candidates,zoom:16).map(\.point.id),["a","c"])
        XCTAssertEqual(visible(candidates,zoom:16,selected:"b").map(\.point.id),["b","c"])
    }
    func testPanelCoveredAndNonfinitePositionsAreExcluded() {
        XCTAssertTrue(visible([candidate("a",5,100),candidate("b",Double.nan,100)],zoom:16).isEmpty)
    }
    func testDisplayCountIsBounded() {
        let candidates=(0..<100).map{candidate(String($0),50+Double($0%10)*60,50+Double($0/10)*60)}
        XCTAssertEqual(visible(candidates,zoom:15).count,12)
        XCTAssertEqual(visible(candidates,zoom:16).count,24)
    }
    private func visible(_ c:[SafetyDisplayCandidate],zoom:Double,selected:String?=nil)->[SafetyDisplayCandidate] {
        SafetyDisplayPolicy.visible(c,zoom:zoom,minX:0,minY:0,maxX:700,maxY:700,selectedID:selected)
    }
    private func candidate(_ id:String,_ x:Double,_ y:Double,kind:SafetyPoint.Kind = .camera)->SafetyDisplayCandidate {
        SafetyDisplayCandidate(point:SafetyPoint(id:id,kind:kind,latitude:37,longitude:127,speedLimit:50,referenceDate:""),x:x,y:y)
    }
}
