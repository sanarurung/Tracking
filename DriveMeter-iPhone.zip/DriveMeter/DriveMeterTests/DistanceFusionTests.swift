import XCTest
@testable import DriveMeter

final class DistanceFusionTests: XCTestCase {
    private func seeded(speed: Double = 10) -> DistanceFusion {
        var engine = DistanceFusion()
        _ = engine.sample(north: 0, west: 0, at: 0)
        _ = engine.observeGPS(distance: nil, speed: speed, speedAccuracy: 0.2,
                              course: 0, horizontalAccuracy: 5, at: 0, motionAvailable: true)
        return engine
    }
    private func gps(_ engine: inout DistanceFusion, distance: Double, speed: Double = 10,
                     at time: Double, motion: Bool = true) -> FusedDistanceUpdate {
        engine.observeGPS(distance: distance, speed: speed, speedAccuracy: 0.2,
                          course: 0, horizontalAccuracy: 5, at: time, motionAvailable: motion)
    }

    func testHealthyGPSUsesMotionAndReducesSyntheticPositionNoise() {
        var engine = seeded()
        for tick in 1...10 { XCTAssertEqual(engine.sample(north: 0, west: 0, at: Double(tick) / 10), 0) }
        let result = gps(&engine, distance: 14, at: 1)
        XCTAssertTrue(result.usesMotion)
        XCTAssertGreaterThan(result.meters, 10)
        XCTAssertLessThan(abs(result.meters - 10), abs(14.0 - 10))
    }

    func testStationaryGPSJitterDoesNotAccumulateFareDistance() {
        var engine = seeded(speed: 0)
        var distance = 0.0
        for second in 1...20 {
            for tick in 1...10 {
                _ = engine.sample(north: 0, west: 0, at: Double(second - 1) + Double(tick) / 10)
            }
            distance += gps(&engine, distance: 8, speed: 0, at: Double(second)).meters
        }
        XCTAssertEqual(distance, 0, accuracy: 0.001)
    }

    func testGPSLimitsVelocityDriftWhileMotionRemainsActive() {
        var engine = seeded()
        for second in 1...20 {
            for tick in 1...10 {
                _ = engine.sample(north: 0.15, west: 0, at: Double(second - 1) + Double(tick) / 10)
            }
            let result = gps(&engine, distance: 10, at: Double(second))
            XCTAssertTrue(result.usesMotion)
            XCTAssertEqual(engine.speed, 10, accuracy: 0.1)
        }
    }

    func testPositionJumpIsRejectedWhenMotionDisagrees() {
        var engine = seeded()
        for tick in 1...10 { _ = engine.sample(north: 0, west: 0, at: Double(tick) / 10) }
        let result = gps(&engine, distance: 40, at: 1)
        XCTAssertTrue(result.rejectsCoordinate)
        XCTAssertEqual(result.meters, 10, accuracy: 0.001)
        for tick in 11...20 { _ = engine.sample(north: 0, west: 0, at: Double(tick) / 10) }
        let recovery = engine.observeGPS(distance: nil, speed: 10, speedAccuracy: 0.2,
                                         course: 0, horizontalAccuracy: 5, at: 2, motionAvailable: true)
        XCTAssertTrue(recovery.breaksRoute)
        XCTAssertEqual(recovery.meters, 10, accuracy: 0.001)
    }

    func testMotionInterruptionFallsBackToGPS() {
        var engine = seeded()
        _ = engine.sample(north: 0, west: 0, at: 1)
        XCTAssertTrue(engine.interrupted)
        let result = gps(&engine, distance: 10, at: 1)
        XCTAssertFalse(result.usesMotion)
        XCTAssertEqual(result.meters, 10)
    }

    func testOutageStopsAt180SecondsAndRecoveryDoesNotDoubleCount() {
        var engine = seeded()
        var distance = 0.0
        for tick in 1...1800 { distance += engine.sample(north: 0, west: 0, at: Double(tick) / 10) }
        XCTAssertEqual(distance, 1800, accuracy: 0.001)
        XCTAssertEqual(engine.sample(north: 0, west: 0, at: 180.1), 0)
        let result = gps(&engine, distance: 1900, at: 181)
        XCTAssertTrue(result.breaksRoute)
        XCTAssertEqual(result.meters, 0)
    }

    func testPauseFlushesTheUncommittedTailOnlyOnce() {
        var engine = seeded()
        for tick in 1...10 { _ = engine.sample(north: 0, west: 0, at: Double(tick) / 10) }
        XCTAssertEqual(engine.finishInterval(at: 1), 10, accuracy: 0.001)
        XCTAssertEqual(engine.finishInterval(at: 1), 0)
    }

    func testUnknownGPSSpeedCannotSeedInertialDeadReckoning() {
        var engine = DistanceFusion()
        _ = engine.observeGPS(distance: nil, speed: -1, speedAccuracy: -1,
                              course: -1, horizontalAccuracy: 5, at: 0, motionAvailable: true)
        for tick in 1...100 { XCTAssertEqual(engine.sample(north: 1, west: 0, at: Double(tick) / 10), 0) }
    }
}
