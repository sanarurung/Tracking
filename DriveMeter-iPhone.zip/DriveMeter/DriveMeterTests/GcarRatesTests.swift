import XCTest
@testable import DriveMeter

final class GcarRatesTests: XCTestCase {
    let policy = TripFarePolicy.customGcar(first: 300, second: 200, third: 100)
    func testFirstBandAndThirtyBoundary() {
        XCTAssertEqual(policy.won(meters: 10_000), 3_000)
        XCTAssertEqual(policy.won(meters: 30_000), 9_000)
    }
    func testSecondBandIsProgressive() {
        XCTAssertEqual(policy.won(meters: 50_000), 13_000)
        XCTAssertEqual(policy.won(meters: 100_000), 23_000)
    }
    func testThirdBandChargesOnlyExcess() {
        XCTAssertEqual(policy.won(meters: 120_000), 25_000)
    }
    func testZeroRatesAreAccepted() {
        XCTAssertEqual(TripFarePolicy.customGcar(first: 0, second: 0, third: 0).won(meters: 500_000), 0)
        XCTAssertEqual(TripFarePolicy.customGcar(first: 0, second: 200, third: 0).won(meters: 120_000), 14_000)
    }
    func testNegativeBandIsInvalid() {
        XCTAssertFalse(TripFarePolicy.customGcar(first: -1, second: 200, third: 100).isValid)
        XCTAssertFalse(TripFarePolicy.customGcar(first: 300, second: -1, third: 100).isValid)
        XCTAssertFalse(TripFarePolicy.customGcar(first: 300, second: 200, third: -1).isValid)
    }
    func testFractionalDistanceProrates() {
        XCTAssertEqual(policy.won(meters: 30_500), 9_100)
        XCTAssertEqual(policy.won(meters: 100_500), 23_050)
    }
    func testLegacyGcarPolicyKeepsOriginalRates() throws {
        let old = Data(#"{"mode":"gcar","wonPerKm":0}"#.utf8)
        let decoded = try JSONDecoder().decode(TripFarePolicy.self, from: old)
        XCTAssertEqual(decoded.effectiveGcarRates, .defaults)
        XCTAssertEqual(decoded.won(meters: 50_000), 13_100)
    }
    func testCustomBandsSurviveSnapshotAndHistory() throws {
        let snapshot = TripSnapshot(meters: 120_000, segments: [], finished: false, farePolicy: policy)
        let restored = try JSONDecoder().decode(TripSnapshot.self, from: JSONEncoder().encode(snapshot))
        XCTAssertEqual(restored.farePolicy, policy)
        let record = TripRecord(id: UUID(), startedAt: nil, endedAt: nil, savedAt: Date(), meters: 120_000,
            estimatedMeters: 0, fusedMeters: 0, fareWon: 25_000, segments: [], calculationVersion: "gcar-custom-v1", farePolicy: policy)
        let history = try JSONDecoder().decode(TripRecord.self, from: JSONEncoder().encode(record))
        XCTAssertEqual(history.farePolicy, policy)
        XCTAssertEqual(history.fareWon, 25_000)
    }
}
