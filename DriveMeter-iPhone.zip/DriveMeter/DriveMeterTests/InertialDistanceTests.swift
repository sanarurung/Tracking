import XCTest
@testable import DriveMeter

final class InertialDistanceTests: XCTestCase {
    func testNoEstimateBeforeGPSSeed() {
        var engine = InertialDistance()
        XCTAssertEqual(engine.sample(north: 1, west: 0, at: 10), 0)
    }

    func testBuffersFirstFiveSecondsAndThenIncludesThem() {
        var engine = InertialDistance()
        engine.seed(speed: 10, course: 0, at: 0)
        for tick in 1..<50 {
            XCTAssertEqual(engine.sample(north: 0, west: 0, at: Double(tick) / 10), 0)
        }
        XCTAssertEqual(engine.sample(north: 0, west: 0, at: 5), 50, accuracy: 0.001)
        XCTAssertTrue(engine.usedFallback)
    }

    func testThreeMinuteLimitAndNoMoreDistanceAfterIt() {
        var engine = InertialDistance()
        engine.seed(speed: 10, course: 0, at: 0)
        var distance = 0.0
        for tick in 1...1800 {
            distance += engine.sample(north: 0, west: 0, at: Double(tick) / 10)
        }
        XCTAssertEqual(distance, 1800, accuracy: 0.001)
        XCTAssertEqual(engine.sample(north: 0, west: 0, at: 180.1), 0)
        XCTAssertTrue(engine.interrupted)
    }

    func testSensorDeliveryInterruptionStopsExtrapolation() {
        var engine = InertialDistance()
        engine.seed(speed: 10, course: 0, at: 0)
        XCTAssertEqual(engine.sample(north: 0, west: 0, at: 2), 0)
        XCTAssertTrue(engine.interrupted)
        XCTAssertEqual(engine.sample(north: 0, west: 0, at: 2.1), 0)
    }

    func testReturningGPSResetsEstimateBuffer() {
        var engine = InertialDistance()
        engine.seed(speed: 10, course: 0, at: 0)
        for tick in 1...60 { _ = engine.sample(north: 0, west: 0, at: Double(tick) / 10) }
        XCTAssertTrue(engine.usedFallback)
        engine.seed(speed: 5, course: 90, at: 6)
        XCTAssertFalse(engine.usedFallback)
        XCTAssertEqual(engine.sample(north: 0, west: 0, at: 6.1), 0)
    }

    func testAccelerationChangesSpeedAndBrakingCannotReverseDistance() {
        var engine = InertialDistance()
        engine.seed(speed: 2, course: 0, at: 0)
        for tick in 1...50 { _ = engine.sample(north: 1, west: 0, at: Double(tick) / 10) }
        XCTAssertGreaterThan(engine.speed, 6)
        for tick in 51...150 {
            XCTAssertGreaterThanOrEqual(engine.sample(north: -5, west: 0, at: Double(tick) / 10), 0)
        }
        XCTAssertEqual(engine.speed, 0, accuracy: 0.001)
    }
}
