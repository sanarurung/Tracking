import XCTest
@testable import DriveMeter

final class MapRecenterPolicyTests: XCTestCase {
    func testLaunchWaitsForFreshFixThenCenters() {
        var policy = MapRecenterPolicy()
        XCTAssertFalse(policy.shouldCenter(request: 0, locationFresh: false))
        XCTAssertFalse(policy.didCenter)
        XCTAssertTrue(policy.shouldCenter(request: 0, locationFresh: true))
    }
    func testNormalUpdatesDoNotOverrideUserPan() {
        var policy = MapRecenterPolicy()
        XCTAssertTrue(policy.shouldCenter(request: 0, locationFresh: true))
        XCTAssertFalse(policy.shouldCenter(request: 0, locationFresh: true))
    }
    func testButtonAndForegroundRequestRemainPendingUntilFreshFix() {
        var policy = MapRecenterPolicy()
        XCTAssertTrue(policy.shouldCenter(request: 0, locationFresh: true))
        XCTAssertFalse(policy.shouldCenter(request: 1, locationFresh: false))
        XCTAssertTrue(policy.shouldCenter(request: 1, locationFresh: true))
        XCTAssertFalse(policy.shouldCenter(request: 1, locationFresh: true))
        XCTAssertTrue(policy.shouldCenter(request: 2, locationFresh: true))
    }
}
