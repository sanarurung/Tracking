import XCTest
import CoreLocation
@testable import DriveMeter

final class SafetyPointTests: XCTestCase {
    func testNearestOrderingAndRadiusAcrossGridBoundary() {
        let points = [point("far", 37.02), point("near",37.0001), point("outside",38)]
        let found = SafetyIndex(points: points).nearby(CLLocation(latitude:37,longitude:127),radius:3_000)
        XCTAssertEqual(found.map(\.id), ["near", "far"])
        XCTAssertTrue(found[0].distance < found[1].distance)
    }
    func testInvalidCoordinatesAndDuplicateIDsAreExcluded() {
        let index=SafetyIndex(points:[point("one",37),point("one",37),point("bad",Double.nan),point("range",91)])
        XCTAssertEqual(index.nearby(CLLocation(latitude:37,longitude:127)).count,1)
    }
    func testMarkerLimitAndInvalidQuery() {
        let index=SafetyIndex(points:(0..<200).map{point(String($0),37 + Double($0)/1_000_000)})
        XCTAssertEqual(index.nearby(CLLocation(latitude:37,longitude:127)).count,150)
        XCTAssertTrue(index.nearby(CLLocation(latitude:37,longitude:127),radius:-1).isEmpty)
    }
    func testCategoryAndUnknownSpeedRemainDistinct() throws {
        let point = try JSONDecoder().decode(SafetyPoint.self, from: Data("{\"id\":\"b\",\"kind\":\"bump\",\"latitude\":37,\"longitude\":127,\"speedLimit\":null,\"referenceDate\":\"2026-10-28\"}".utf8))
        XCTAssertEqual(point.kind,.bump)
        XCTAssertNil(point.speedLimit)
    }
    private func point(_ id:String,_ latitude:Double) -> SafetyPoint {
        SafetyPoint(id:id,kind:.camera,latitude:latitude,longitude:127,speedLimit:nil,referenceDate:"")
    }
}
