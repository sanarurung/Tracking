import XCTest
@testable import DriveMeter

final class LocationBannerContentTests: XCTestCase {
    let content = LocationBannerContent(source: "naver", district: "가상시 예시구", road: "테스트로")
    func testRegionForFirstFiveSeconds() {
        XCTAssertEqual(content.text(elapsed: 0), "가상시 예시구")
        XCTAssertEqual(content.text(elapsed: 4.999), "가상시 예시구")
    }
    func testRoadForNextFiveSeconds() {
        XCTAssertEqual(content.text(elapsed: 5), "테스트로")
        XCTAssertEqual(content.text(elapsed: 9.999), "테스트로")
    }
    func testRepeatsAtTenSeconds() { XCTAssertEqual(content.text(elapsed: 10), "가상시 예시구") }
    func testMissingRoadIsExplicit() {
        XCTAssertEqual(LocationBannerContent(source: "naver", district: "가상동", road: nil).text(elapsed: 5), "도로명 정보 없음")
    }
    func testOnlyNaverSourceIsAccepted() {
        XCTAssertTrue(content.isValid)
        XCTAssertFalse(LocationBannerContent(source: "other", district: "가상동", road: nil).isValid)
    }
    func testCompactServerResponseDecodes() throws {
        let data = Data(#"{"source":"naver","district":"가상동","road":null}"#.utf8)
        let decoded = try JSONDecoder().decode(LocationBannerContent.self, from: data)
        XCTAssertTrue(decoded.isValid)
        XCTAssertEqual(decoded.text(elapsed: 0), "가상동")
    }
}
