import Foundation
import CoreLocation

struct SafetyPoint: Codable, Identifiable {
    enum Kind: String, Codable { case camera, signal, bump }
    let id: String
    let kind: Kind
    let latitude: Double
    let longitude: Double
    let speedLimit: Int?
    let referenceDate: String

    var title: String {
        switch kind {
        case .camera: return "과속 카메라"
        case .signal: return "신호 단속 카메라"
        case .bump: return "과속방지턱"
        }
    }
    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
    var isValid: Bool {
        !id.isEmpty && latitude.isFinite && longitude.isFinite &&
        (-90...90).contains(latitude) && (-180...180).contains(longitude)
    }
}

struct NearbySafetyPoint: Identifiable {
    let point: SafetyPoint
    let distance: Double
    var id: String { point.id }
}

/// Grid lookup avoids scanning the entire national snapshot on each GPS fix.
struct SafetyIndex {
    private struct Cell: Hashable { let latitude: Int; let longitude: Int }
    private var cells: [Cell: [SafetyPoint]] = [:]
    private let cellSize = 0.02

    init(points: [SafetyPoint]) {
        var ids = Set<String>()
        for point in points where point.isValid && ids.insert(point.id).inserted {
            let cell = Cell(latitude: Int(floor(point.latitude / cellSize)),
                            longitude: Int(floor(point.longitude / cellSize)))
            cells[cell, default: []].append(point)
        }
    }

    func nearby(_ location: CLLocation, radius: Double = 2_000, limit: Int = 150) -> [NearbySafetyPoint] {
        let c = location.coordinate
        guard CLLocationCoordinate2DIsValid(c), radius > 0, radius <= 10_000, limit > 0 else { return [] }
        let latDelta = radius / 110_000
        let lonDelta = latDelta / max(0.1, cos(c.latitude * .pi / 180))
        var result: [NearbySafetyPoint] = []
        for lat in Int(floor((c.latitude-latDelta)/cellSize))...Int(floor((c.latitude+latDelta)/cellSize)) {
            for lon in Int(floor((c.longitude-lonDelta)/cellSize))...Int(floor((c.longitude+lonDelta)/cellSize)) {
                for point in cells[Cell(latitude: lat, longitude: lon)] ?? [] {
                    let distance = location.distance(from: CLLocation(latitude: point.latitude, longitude: point.longitude))
                    if distance <= radius { result.append(NearbySafetyPoint(point: point, distance: distance)) }
                }
            }
        }
        return Array(result.sorted { $0.distance == $1.distance ? $0.id < $1.id : $0.distance < $1.distance }.prefix(limit))
    }
}
