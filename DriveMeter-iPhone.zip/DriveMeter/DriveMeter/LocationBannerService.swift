import Foundation
import CoreLocation
import Combine
import Security

private final class AddressNoRedirect: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

@MainActor
final class LocationBannerService: ObservableObject {
    @Published private(set) var content: LocationBannerContent?
    @Published private(set) var message = "네이버 주소 조회 연결 설정"
    @Published private(set) var cycleStart = Date()
    private(set) var endpointText = UserDefaults.standard.string(forKey: "address-proxy-url") ?? ""
    private var task: Task<Void, Never>?
    private var active = true
    private var latest: CLLocation?
    private var resolvedLocation: CLLocation?
    private var resolvedAt = Date.distantPast
    private var requestedAt = Date.distantPast
    private var attemptedLocation: CLLocation?
    private var generation = 0
    private let session = URLSession(configuration: .ephemeral, delegate: AddressNoRedirect(), delegateQueue: nil)
    private let keychainService = "DriveMeter.AddressProxy"

    var storedToken: String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService, kSecAttrAccount as String: "access-token",
            kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var value: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &value) == errSecSuccess, let data = value as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    var configured: Bool { validEndpoint(endpointText) != nil && !storedToken.isEmpty }

    func configure(endpoint: String, token: String) -> Bool {
        let text = endpoint.trimmingCharacters(in: .whitespacesAndNewlines)
        let token = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard validEndpoint(text) != nil, token.count >= 16, token.count <= 512,
              !token.contains("\n"), !token.contains("\r") else { return false }
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService, kSecAttrAccount as String: "access-token"]
        let values: [String: Any] = [kSecValueData as String: Data(token.utf8),
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
        let status = SecItemUpdate(query as CFDictionary, values as CFDictionary)
        if status == errSecItemNotFound {
            guard SecItemAdd(query.merging(values) { _, new in new } as CFDictionary, nil) == errSecSuccess else { return false }
        } else if status != errSecSuccess { return false }
        endpointText = text
        UserDefaults.standard.set(text, forKey: "address-proxy-url")
        invalidate()
        requestedAt = .distantPast
        observe(latest)
        return true
    }

    private func validEndpoint(_ text: String) -> URL? {
        guard let url = URL(string: text), url.scheme?.lowercased() == "https", url.host != nil,
              url.user == nil, url.password == nil, url.query == nil, url.fragment == nil else { return nil }
        return url
    }
    func setActive(_ value: Bool) {
        active = value
        if !value { generation += 1; task?.cancel(); task = nil }
        else { observe(latest) }
    }
    private func invalidate() {
        generation += 1; task?.cancel(); task = nil
        content = nil; resolvedLocation = nil; resolvedAt = .distantPast
        cycleStart = Date()
    }
    func observe(_ location: CLLocation?) {
        latest = location
        guard let location, CLLocationCoordinate2DIsValid(location.coordinate),
              (0...100).contains(location.horizontalAccuracy), abs(location.timestamp.timeIntervalSinceNow) <= 10 else {
            invalidate(); message = "현재 위치 수신 대기"; return
        }
        guard active else { return }
        guard let endpoint = validEndpoint(endpointText), !storedToken.isEmpty else {
            message = "네이버 주소 조회 연결 설정"; return
        }
        let now = Date()
        guard task == nil, now.timeIntervalSince(requestedAt) >= 10 else { return }
        if let attemptedLocation, location.distance(from: attemptedLocation) < 30,
           now.timeIntervalSince(requestedAt) < 60 { return }
        requestedAt = now; attemptedLocation = location
        let token = storedToken
        let requestGeneration = generation
        message = "네이버 주소 조회 중"
        task = Task { [weak self] in
            guard let self else { return }
            defer { if self.generation == requestGeneration { self.task = nil } }
            do {
                var request = URLRequest(url: endpoint)
                request.httpMethod = "POST"
                request.timeoutInterval = 8
                request.cachePolicy = .reloadIgnoringLocalCacheData
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
                request.httpBody = try JSONEncoder().encode(["latitude": location.coordinate.latitude, "longitude": location.coordinate.longitude])
                let (data, response) = try await self.session.data(for: request)
                guard !Task.isCancelled, self.generation == requestGeneration, self.active else { return }
                guard let http = response as? HTTPURLResponse, http.statusCode == 200, data.count <= 4096 else {
                    self.message = "네이버 주소 연결 확인 필요"; self.content = nil; return
                }
                let result = try JSONDecoder().decode(LocationBannerContent.self, from: data)
                guard result.isValid else { throw CocoaError(.fileReadCorruptFile) }
                if self.content == nil { self.cycleStart = Date() }
                self.content = result; self.resolvedLocation = location; self.resolvedAt = Date()
            } catch {
                guard !Task.isCancelled, self.generation == requestGeneration else { return }
                self.content = nil; self.message = "네이버 주소 조회 재시도 대기"
            }
        }
    }
    func text(at now: Date) -> String {
        guard let latest, abs(latest.timestamp.timeIntervalSince(now)) <= 10 else { return "현재 위치 수신 대기" }
        guard configured else { return "네이버 주소 조회 연결 설정" }
        guard let content, let resolvedLocation, latest.distance(from: resolvedLocation) <= 200,
              now.timeIntervalSince(resolvedAt) <= 60 else { return message }
        return content.text(elapsed: now.timeIntervalSince(cycleStart))
    }
}
