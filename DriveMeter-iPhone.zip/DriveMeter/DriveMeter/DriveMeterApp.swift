import SwiftUI

@main
struct DriveMeterApp: App {
    @StateObject private var tracker = TripTracker()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView(tracker: tracker)
                .onChange(of: scenePhase) { _, value in
                    if value != .active { tracker.persist() }
                }
        }
    }
}
