import SwiftUI

@main
struct DriveMeterApp: App {
    @StateObject private var tracker = TripTracker()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView(tracker: tracker)
                .onChange(of: scenePhase) { _, value in
                    tracker.setAppActive(value == .active)
                    if value != .active { tracker.persist() }
                }
        }
    }
}
