import SwiftUI
import UIKit

@main
struct DriveMeterApp: App {
    @StateObject private var tracker = TripTracker()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView(tracker: tracker)
                .onAppear {
                    UIApplication.shared.isIdleTimerDisabled = scenePhase == .active
                    tracker.setAppActive(scenePhase == .active)
                }
                .onDisappear { UIApplication.shared.isIdleTimerDisabled = false }
                .onChange(of: scenePhase) { _, value in
                    UIApplication.shared.isIdleTimerDisabled = value == .active
                    tracker.setAppActive(value == .active)
                    if value != .active { tracker.persist() }
                }
        }
    }
}
