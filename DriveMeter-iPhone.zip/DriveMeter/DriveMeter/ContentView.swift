import SwiftUI
import CoreLocation

struct ContentView: View {
    @ObservedObject var tracker: TripTracker
    @Environment(\.scenePhase) private var scenePhase
    @State private var topPanelHeight: CGFloat = 260
    @State private var bottomPanelHeight: CGFloat = 150
    @State private var recenterRequest = 0
    @State private var showSafety = false
    @State private var showRates = false
    @State private var confirmReset = false
    @State private var confirmFinish = false
    @State private var showDriveMode = false

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                NaverRouteMap(segments: tracker.segments, recenterRequest: recenterRequest,
                              safetyPoints: tracker.nearbySafety.map(\.point),
                              currentLocation: tracker.currentLocation,
                              trackingEnabled: tracker.locationAccessGranted,
                              contentInsets: UIEdgeInsets(top: geometry.safeAreaInsets.top + topPanelHeight + 20,
                                                          left: 16,
                                                          bottom: geometry.safeAreaInsets.bottom + bottomPanelHeight + 20,
                                                          right: 16))
                    .ignoresSafeArea()
                VStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 12) {
                        dashboard
                        HStack(alignment: .top) {
                            speedometer
                            Spacer(minLength: 8)
                            automaticSafetyWarning

                        }
                    }
                    .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { topPanelHeight = $0 }
                    Spacer(minLength: 12)
                    controls
                        .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { bottomPanelHeight = $0 }
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 12)
            }
            .overlay(alignment: .topTrailing) {
                Button { tracker.prepareMapLocation(showError: true); recenterRequest += 1 } label: {
                    Image(systemName: "location.fill").font(.title3)
                        .frame(width: 48, height: 48)
                }
                .buttonStyle(.glass)
                .buttonBorderShape(.circle)
                .accessibilityLabel("현재 위치로 이동")
                .padding(.trailing, 16)
                .padding(.top, min(topPanelHeight + 28, geometry.size.height * 0.42))
            }
        }
        .task { tracker.prepareMapLocation(); recenterRequest += 1 }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { tracker.prepareMapLocation(); recenterRequest += 1 }
        }
        .sheet(isPresented: $showSafety) { SafetyInfoView(tracker: tracker) }
        .tint(.blue)
        .sheet(isPresented: $showRates) { rates }
        .confirmationDialog("주행 모드를 선택해 주세요", isPresented: $showDriveMode, titleVisibility: .visible) {
            Button("쏘가 모드") { tracker.start() }
            Button("Gcar(기타) 모드") { tracker.start() }
            Button("취소", role: .cancel) {}
        }
        .confirmationDialog("일시정지한 현재 측정을 초기화할까요? 저장된 과거 기록은 유지됩니다.", isPresented: $confirmReset, titleVisibility: .visible) {
            Button("현재 측정 초기화", role: .destructive) { tracker.reset() }
        }
        .confirmationDialog("주행을 종료하고 최종 요금을 확정할까요?", isPresented: $confirmFinish, titleVisibility: .visible) {
            Button("주행 종료") { tracker.finish() }
        }
        .alert("확인이 필요합니다", isPresented: Binding(get: { tracker.problem != nil }, set: { if !$0 { tracker.problem = nil } })) {
            Button("설정 열기") {
                if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
            }
            Button("확인", role: .cancel) { tracker.problem = nil }
        } message: { Text(tracker.problem ?? "") }
    }

    private var automaticSafetyWarning: some View {
        TimelineView(.periodic(from: .now, by: 1)) { context in
            VStack(alignment: .trailing, spacing: 6) {
                if let warning = tracker.approachWarning, warning.isFresh(at: context.date) {
                    HStack(spacing: 8) {
                        Image(uiImage: SafetyMarkerArtwork.image(for: warning.point))
                            .resizable().frame(width: 60, height: 60)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("전방 약 \(Int(warning.distance.rounded()))m")
                                .font(.headline).monospacedDigit()
                            Text(warning.point.title).font(.caption.weight(.semibold))
                        }
                    }
                    .foregroundStyle(.black)
                    .shadow(color: .white, radius: 2)
                    .accessibilityElement(children: .combine)
                }
                Button { showSafety = true } label: {
                    Text("안전정보 · © OpenStreetMap 기여자")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundStyle(.black).shadow(color: .white, radius: 2)
                }.buttonStyle(.plain)
            }.padding(.top, 8)
        }
    }

    private var speedometer: some View {
        TimelineView(.periodic(from: .now, by: 1)) { context in
            let speed = tracker.speedReading?.kilometresPerHour(at: context.date)
            VStack(alignment: .leading, spacing: 4) {
                Label("현재 속도", systemImage: "speedometer")
                    .font(.caption).foregroundStyle(.secondary)
                HStack(alignment: .firstTextBaseline, spacing: 5) {
                    Text(speed.map { String(Int($0.rounded())) } ?? "—")
                        .font(.system(size: 38, weight: .bold, design: .rounded))
                        .contentTransition(.numericText())
                    Text("km/h").font(.subheadline)
                }.monospacedDigit()
                Text(speed == nil ? "속도 측정 대기" :
                     tracker.speedReading?.source == .inertial ? "센서 추정 · 오차 가능" :
                     tracker.speedReading?.source == .gpsMotion ? "GPS + 가속도계" : "GPS · 센서 보정 대기")
                    .font(.caption2).foregroundStyle(tracker.speedReading?.source == .inertial ? Color.orange : Color.secondary)
            }
            .padding(.horizontal, 18).padding(.vertical, 12)
            .glassEffect(.regular, in: .rect(cornerRadius: 24))
            .accessibilityElement(children: .combine)
        }
    }

    private var dashboard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("주행 요금계", systemImage: "steeringwheel").font(.headline)
                Spacer()
                Button { showRates = true } label: {
                    Label("요금표", systemImage: "info.circle").font(.subheadline)
                }.buttonStyle(.plain).foregroundStyle(.blue)
            }
            ViewThatFits(in: .horizontal) {
                HStack(alignment: .firstTextBaseline, spacing: 22) {
                    metric("주행거리", value: tracker.meters / 1000, unit: "km")
                    Rectangle().fill(.secondary.opacity(0.25)).frame(width: 1, height: 46)
                    fareMetric
                }
                VStack(alignment: .leading, spacing: 12) {
                    metric("주행거리", value: tracker.meters / 1000, unit: "km")
                    fareMetric
                }
            }
            HStack(spacing: 7) {
                Circle().fill(tracker.isEstimating ? Color.orange : (tracker.phase == .recording ? Color.green : Color.gray)).frame(width: 7, height: 7)
                Text(tracker.status).font(.caption).foregroundStyle(.secondary)
            }
            .accessibilityElement(children: .combine)
            if let notice = tracker.liveActivityNotice { Text(notice).font(.caption2).foregroundStyle(.orange) }
            if tracker.estimatedMeters > 0 {
                Text("센서 추정 포함 \((tracker.estimatedMeters / 1000).formatted(.number.precision(.fractionLength(2))))km · 오차 가능")
                    .font(.caption).foregroundStyle(.orange)
            }
        }
        .foregroundStyle(.primary).padding(.horizontal, 22).padding(.vertical, 12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassEffect(.regular, in: .rect(cornerRadius: 28))
    }

    private func metric(_ title: String, value: Double, unit: String) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(value, format: .number.precision(.fractionLength(2))).font(.system(size: 34, weight: .bold, design: .rounded))
                Text(unit).font(.subheadline)
            }.monospacedDigit()
        }.accessibilityElement(children: .combine)
    }

    private var fareMetric: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(tracker.phase == .finished ? "최종 요금" : "예상 요금").font(.caption).foregroundStyle(.secondary)
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(tracker.fare, format: .number).font(.system(size: 34, weight: .bold, design: .rounded))
                Text("원").font(.subheadline)
            }.monospacedDigit()
        }.accessibilityElement(children: .combine)
    }

    private var controls: some View {
        GlassEffectContainer(spacing: 16) {
          VStack(spacing: 14) {
            HStack(spacing: 8) {
                Image(systemName: "point.bottomleft.forward.to.point.topright.scurvepath").foregroundStyle(.blue)
                Text("이동한 경로가 파란 선으로 표시됩니다").font(.caption).foregroundStyle(.secondary)
            }.padding(.horizontal, 14).padding(.vertical, 9)
                .glassEffect(.regular, in: .capsule)
            HStack(spacing: 12) {
                switch tracker.phase {
                case .ready:
                    action("주행 시작", symbol: "play.fill") { showDriveMode = true }
                case .recording:
                    action("일시정지", symbol: "pause.fill") { tracker.pause() }
                    Button("종료") { confirmFinish = true }.buttonStyle(.glass).controlSize(.large)
                case .paused:
                    action("주행 재개", symbol: "play.fill") { tracker.start() }
                    Button("종료") { confirmFinish = true }.buttonStyle(.glass).controlSize(.large)
                case .finished:
                    if tracker.needsArchiveRetry {
                        action("저장 재시도", symbol: "arrow.clockwise") { tracker.retryArchive() }
                    } else {
                        action("새 주행", symbol: "plus") { tracker.reset() }
                    }
                }
            }
            if tracker.phase == .paused {
                Button("기록 초기화", role: .destructive) { confirmReset = true }
                    .font(.caption).buttonStyle(.glass)
            }
          }.frame(maxWidth: .infinity)
        }
    }

    private func action(_ title: String, symbol: String, perform: @escaping () -> Void) -> some View {
        Button(action: perform) {
            Label(title, systemImage: symbol).font(.headline).frame(maxWidth: .infinity).padding(.vertical, 6)
        }.buttonStyle(.glassProminent).buttonBorderShape(.capsule).controlSize(.large)
    }

    private var rates: some View {
        NavigationStack {
            List {
                Section("구간별 누진 요금") {
                    rate("0~30km", "270원/km")
                    rate("30km 초과~100km", "250원/km")
                    rate("100km 초과", "220원/km")
                }
                Section("계산 예시") {
                    rate("30km", "8,100원")
                    rate("50km", "13,100원")
                    rate("100km", "25,600원")
                    rate("120km", "30,000원")
                }
                Section {
                    Text("기본요금 없이 첫 이동부터 계산합니다. 1km 미만도 실제 거리에 비례해 계산하며 최종 금액을 원 단위로 반올림합니다.")
                    Text("GPS가 정상일 때도 센서로 이동량을 예측하고 GPS 속도·정확도로 보정합니다. 센서 수신이 불안정하거나 방향 보정이 안 되면 GPS만 사용합니다. 정확도 향상은 보장되지 않으며 실차 비교가 필요합니다.")
                    Text("GPS 음영 구간은 최대 3분(180초)간 센서로 추정합니다. 추정 거리는 요금에 포함되며 별도로 표시됩니다. GPS 기준 속도·방향이 없거나 센서 사용 불가 또는 추정 한도 이후 구간은 계산하지 않습니다.")
                    Text("휴대폰을 거치대에 고정해 주세요. 센서 오차, 커브·회전, 자기장, GPS 수신 상태에 따라 실제 거리와 차이가 납니다. GPS 복귀 시 추정값은 유지하며 해당 구간을 다시 더하지 않습니다. 추정 경로는 지도에 그리지 않습니다. 화면 잠금·백그라운드에서 센서 수신이 끊기면 GPS 복귀까지 추정을 멈춥니다.")
                    Text("종료한 주행은 주행 기록에 자동 보관합니다. 새 주행을 시작해도 과거 기록은 남습니다. 진행 중 기록은 앱 재실행 시 일시정지로 복원됩니다. 강제 종료 중에는 측정할 수 없습니다.")
                }.font(.footnote).foregroundStyle(.secondary)
            }
            .navigationTitle("요금 안내").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("완료") { showRates = false } } }
        }.presentationDetents([.medium, .large])
    }

    private func rate(_ title: String, _ value: String) -> some View {
        HStack { Text(title); Spacer(); Text(value).fontWeight(.semibold) }
    }
}
