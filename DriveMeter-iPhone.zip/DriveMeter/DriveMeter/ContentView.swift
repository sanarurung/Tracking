import SwiftUI
import MapKit

struct ContentView: View {
    @ObservedObject var tracker: TripTracker
    @State private var camera: MapCameraPosition = .userLocation(fallback: .region(
        MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 37.5665, longitude: 126.9780),
                           span: MKCoordinateSpan(latitudeDelta: 0.025, longitudeDelta: 0.025))))
    @State private var showRates = false
    @State private var confirmReset = false
    @State private var confirmFinish = false
    private let navy = Color(red: 0.06, green: 0.12, blue: 0.22)

    var body: some View {
        Map(position: $camera) {
            UserAnnotation()
            ForEach(tracker.segments.indices, id: \.self) { index in
                MapPolyline(coordinates: tracker.segments[index].map(\.coordinate))
                    .stroke(.blue, style: StrokeStyle(lineWidth: 6, lineCap: .round, lineJoin: .round))
            }
        }
        .mapStyle(.standard(elevation: .flat))
        .mapControls { MapCompass(); MapScaleView() }
        .safeAreaInset(edge: .top, spacing: 0) { dashboard }
        .safeAreaInset(edge: .bottom, spacing: 0) { controls }
        .overlay(alignment: .trailing) {
            Button {
                camera = .userLocation(fallback: .automatic)
            } label: {
                Image(systemName: "location.fill").font(.title3)
                    .padding(15).background(.regularMaterial, in: Circle())
            }
            .accessibilityLabel("현재 위치로 이동")
            .padding(.trailing, 16)
        }
        .tint(.blue)
        .sheet(isPresented: $showRates) { rates }
        .confirmationDialog("현재 기록을 지우고 새 주행을 시작할까요?", isPresented: $confirmReset, titleVisibility: .visible) {
            Button("기록 지우기", role: .destructive) { tracker.reset() }
        }
        .confirmationDialog("주행을 종료하고 최종 요금을 확정할까요?", isPresented: $confirmFinish, titleVisibility: .visible) {
            Button("주행 종료") { tracker.finish() }
        }
        .alert("확인이 필요합니다", isPresented: Binding(get: { tracker.problem != nil }, set: { if !$0 { tracker.problem = nil } })) {
            Button("설정 열기") {
                if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
            }
            Button("확인", role: .cancel) { tracker.problem = nil }
        } message: { Text(tracker.problem ?? "") }
    }

    private var dashboard: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Label("주행 요금계", systemImage: "steeringwheel").font(.headline)
                Spacer()
                Button { showRates = true } label: {
                    Label("요금표", systemImage: "info.circle").font(.subheadline)
                }.tint(.white)
            }
            ViewThatFits(in: .horizontal) {
                HStack(alignment: .firstTextBaseline, spacing: 22) {
                    metric("주행거리", value: tracker.meters / 1000, unit: "km")
                    Rectangle().fill(.white.opacity(0.2)).frame(width: 1, height: 46)
                    fareMetric
                }
                VStack(alignment: .leading, spacing: 12) {
                    metric("주행거리", value: tracker.meters / 1000, unit: "km")
                    fareMetric
                }
            }
            HStack(spacing: 7) {
                Circle().fill(tracker.isEstimating ? Color.orange : (tracker.phase == .recording ? Color.green : Color.gray)).frame(width: 7, height: 7)
                Text(tracker.status).font(.caption).foregroundStyle(.white.opacity(0.8))
            }
            .accessibilityElement(children: .combine)
            if tracker.estimatedMeters > 0 {
                Text("센서 추정 포함 \((tracker.estimatedMeters / 1000).formatted(.number.precision(.fractionLength(2))))km · 오차 가능")
                    .font(.caption).foregroundStyle(.orange)
            }
        }
        .foregroundStyle(.white).padding(22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(navy)
    }

    private func metric(_ title: String, value: Double, unit: String) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title).font(.caption).foregroundStyle(.white.opacity(0.65))
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(value, format: .number.precision(.fractionLength(2))).font(.system(size: 34, weight: .bold, design: .rounded))
                Text(unit).font(.subheadline)
            }.monospacedDigit()
        }.accessibilityElement(children: .combine)
    }

    private var fareMetric: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(tracker.phase == .finished ? "최종 요금" : "예상 요금").font(.caption).foregroundStyle(.white.opacity(0.65))
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(tracker.fare, format: .number).font(.system(size: 34, weight: .bold, design: .rounded))
                Text("원").font(.subheadline)
            }.monospacedDigit()
        }.accessibilityElement(children: .combine)
    }

    private var controls: some View {
        VStack(spacing: 14) {
            HStack(spacing: 8) {
                Image(systemName: "point.bottomleft.forward.to.point.topright.scurvepath").foregroundStyle(.blue)
                Text("이동한 경로가 파란 선으로 표시됩니다").font(.caption).foregroundStyle(.secondary)
            }
            HStack(spacing: 12) {
                switch tracker.phase {
                case .ready:
                    action("주행 시작", symbol: "play.fill") { tracker.start() }
                case .recording:
                    action("일시정지", symbol: "pause.fill") { tracker.pause() }
                    Button("종료") { confirmFinish = true }.buttonStyle(.bordered).controlSize(.large)
                case .paused:
                    action("주행 재개", symbol: "play.fill") { tracker.start() }
                    Button("종료") { confirmFinish = true }.buttonStyle(.bordered).controlSize(.large)
                case .finished:
                    action("새 주행", symbol: "arrow.counterclockwise") { confirmReset = true }
                }
            }
            if tracker.phase == .paused {
                Button("기록 초기화", role: .destructive) { confirmReset = true }.font(.caption)
            }
        }.padding(20).frame(maxWidth: .infinity).background(.regularMaterial)
    }

    private func action(_ title: String, symbol: String, perform: @escaping () -> Void) -> some View {
        Button(action: perform) {
            Label(title, systemImage: symbol).font(.headline).frame(maxWidth: .infinity).padding(.vertical, 6)
        }.buttonStyle(.borderedProminent).controlSize(.large)
    }

    private var rates: some View {
        NavigationStack {
            List {
                Section("구간별 누진 요금") {
                    rate("0~30km", "270원/km")
                    rate("30km 초과~100km", "250원/km")
                    rate("100km 초과", "220원/km")
                }
                Section("계산 예시") {
                    rate("30km", "8,100원")
                    rate("50km", "13,100원")
                    rate("100km", "25,600원")
                    rate("120km", "30,000원")
                }
                Section {
                    Text("기본요금 없이 첫 이동부터 계산합니다. 1km 미만도 실제 거리에 비례해 계산하며 최종 금액을 원 단위로 반올림합니다.")
                    Text("GPS 음영 구간은 마지막 GPS 속도·진행방향과 가속도계·자이로 데이터를 이용해 최대 3분(180초)간 거리를 추정합니다. 추정 거리는 요금에 포함되며 별도로 표시됩니다. GPS 수신 전, 센서 사용 불가 또는 추정 한도 이후 구간은 계산하지 않습니다.")
                    Text("휴대폰을 거치대에 고정해 주세요. 센서 오차, 커브·회전, 자기장, GPS 수신 상태에 따라 실제 거리와 차이가 납니다. GPS 복귀 시 추정값은 유지하며 해당 구간을 다시 더하지 않습니다. 추정 경로는 지도에 그리지 않습니다. 화면 잠금·백그라운드에서 센서 수신이 끊기면 GPS 복귀까지 추정을 멈춥니다.")
                    Text("기록은 이 기기에 저장됩니다. 앱을 다시 열면 일시정지 상태로 복원됩니다. 강제 종료 중에는 측정할 수 없습니다.")
                }.font(.footnote).foregroundStyle(.secondary)
            }
            .navigationTitle("요금 안내").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("완료") { showRates = false } } }
        }.presentationDetents([.medium, .large])
    }

    private func rate(_ title: String, _ value: String) -> some View {
        HStack { Text(title); Spacer(); Text(value).fontWeight(.semibold) }
    }
}
