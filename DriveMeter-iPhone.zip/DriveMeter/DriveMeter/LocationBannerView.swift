import SwiftUI

struct LocationBannerView: View {
    @ObservedObject var service: LocationBannerService
    @State private var showSetup = false
    @State private var endpoint = ""
    @State private var token = ""
    @State private var invalid = false
    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { context in
            Button {
                endpoint = service.endpointText; token = service.storedToken
                invalid = false; showSetup = true
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: LocationBannerContent.showsRoad(elapsed: context.date.timeIntervalSince(service.cycleStart)) ? "road.lanes" : "mappin.and.ellipse")
                        .foregroundStyle(.blue)
                    Text(service.text(at: context.date)).font(.caption).foregroundStyle(.secondary)
                        .lineLimit(1).minimumScaleFactor(0.75)
                }.padding(.horizontal, 14).padding(.vertical, 9)
                    .glassEffect(.regular, in: .capsule)
            }.buttonStyle(.plain).accessibilityHint("네이버 주소 조회 연결 설정")
        }
        .sheet(isPresented: $showSetup) {
            NavigationStack {
                Form {
                    Section("네이버 주소 조회 연결") {
                        TextField("https://서버주소/reverse-geocode", text: $endpoint)
                            .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        SecureField("중계 서버 접근 토큰", text: $token)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    Section {
                        Text("현재 위치 좌표를 설정한 중계 서버와 네이버에 전송해 지역명·도로명을 조회합니다. 지역명과 도로명을 5초 간격으로 표시합니다.")
                        Text("네이버 Client Secret은 서버에만 설정하세요. 이 화면에는 중계 서버용 접근 토큰을 입력합니다.")
                        Text("도로명 주소는 조회 좌표 주변의 주소이며, 실제 주행 도로와 차이가 있을 수 있습니다.")
                    }.font(.footnote)
                    if invalid { Text("HTTPS 서버 주소와 16자 이상의 접근 토큰을 확인해 주세요.").foregroundStyle(.red) }
                    Button("저장하고 연결") {
                        if service.configure(endpoint: endpoint, token: token) { showSetup = false }
                        else { invalid = true }
                    }
                }
                .navigationTitle("주소 조회 설정").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("닫기") { showSetup = false } } }
            }.presentationDetents([.large])
        }
    }
}
