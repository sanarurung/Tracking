import Foundation

/// Short GPS outages only. This is an estimate, never an odometer replacement.
struct InertialDistance {
    static let outageThreshold = 5.0
    static let maximumOutage = 180.0
    private(set) var speed = 0.0
    private(set) var hasSeed = false
    private(set) var usedFallback = false
    private(set) var interrupted = false
    private var gpsTime: Double?
    private var sampleTime: Double?
    private var pendingMeters = 0.0
    private var filteredAcceleration = 0.0
    private var courseRadians = 0.0

    mutating func seed(speed: Double, course: Double, at time: Double) {
        // Seeding requires a usable GPS speed and a course when moving.
        guard speed.isFinite, course.isFinite, time.isFinite,
              (0...70).contains(speed), (0..<360).contains(course) else {
            self = InertialDistance()
            return
        }
        self.speed = speed
        courseRadians = max(0, course) * .pi / 180
        gpsTime = time
        sampleTime = time
        pendingMeters = 0
        filteredAcceleration = 0
        usedFallback = false
        interrupted = false
        hasSeed = true
    }

    /// Acceleration in a true-north / west / up reference frame, m/s².
    /// Returns only newly chargeable estimated metres, including the buffered onset.
    mutating func sample(north: Double, west: Double, at time: Double) -> Double {
        guard hasSeed, !interrupted, north.isFinite, west.isFinite, time.isFinite,
              let gpsTime, let previous = sampleTime else { return 0 }
        let delta = time - previous
        let age = time - gpsTime
        guard delta > 0 else { return 0 }
        guard delta <= 0.5, age <= Self.maximumOutage else {
            interrupted = true
            pendingMeters = 0
            return 0
        }
        sampleTime = time
        // Project gravity-free acceleration onto the last GPS direction of travel.
        let alongTrack = north * cos(courseRadians) - west * sin(courseRadians)
        let alpha = 1 - exp(-delta / 0.3)
        filteredAcceleration += alpha * (alongTrack - filteredAcceleration)
        let acceleration = abs(filteredAcceleration) < 0.06 ? 0 : min(3, max(-5, filteredAcceleration))
        let oldSpeed = speed
        speed = min(70, max(0, speed + acceleration * delta))
        pendingMeters += (oldSpeed + speed) * 0.5 * delta
        guard age >= Self.outageThreshold else { return 0 }
        usedFallback = true
        let result = pendingMeters
        pendingMeters = 0
        return result
    }
}
