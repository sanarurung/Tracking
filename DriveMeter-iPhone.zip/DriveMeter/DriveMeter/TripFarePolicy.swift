import Foundation

struct TripFarePolicy: Codable, Equatable {
    enum Mode: String, Codable { case gcar, socar }
    let mode: Mode
    let wonPerKm: Int
    static let gcar = TripFarePolicy(mode: .gcar, wonPerKm: 0)
    var isValid: Bool { wonPerKm >= 0 }
    var summary: String {
        mode == .socar ? "쏘카 · 30km 무료 · 초과 \(wonPerKm.formatted())원/km" : "Gcar(기타) · 구간별 누진 요금"
    }
    func won(meters: Double) -> Int {
        guard isValid, meters.isFinite, meters > 0 else { return 0 }
        if mode == .gcar { return FareCalculator.won(meters: meters) }
        let amount = max(meters / 1000 - 30, 0) * Double(wonPerKm)
        return Int(min(amount.rounded(), Double(Int.max / 2)))
    }
    static func parseRate(_ text: String) -> Int? {
        let text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.utf8.allSatisfy({ (48...57).contains($0) }) else { return nil }
        return Int(text)
    }
}
