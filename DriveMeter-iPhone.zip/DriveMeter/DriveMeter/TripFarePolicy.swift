import Foundation

struct TripFarePolicy: Codable, Equatable {
    enum Mode: String, Codable { case gcar, socar }
    let mode: Mode
    struct GcarRates: Codable, Equatable {
        let first: Int
        let second: Int
        let third: Int
        static let defaults = GcarRates(first: 270, second: 250, third: 220)
        var isValid: Bool { first >= 0 && second >= 0 && third >= 0 }
    }
    let wonPerKm: Int
    var gcarRates: GcarRates? = nil
    var effectiveGcarRates: GcarRates { gcarRates ?? .defaults }
    static func customGcar(first: Int, second: Int, third: Int) -> TripFarePolicy {
        TripFarePolicy(mode: .gcar, wonPerKm: 0, gcarRates: GcarRates(first: first, second: second, third: third))
    }
    static let gcar = TripFarePolicy(mode: .gcar, wonPerKm: 0)
    var isValid: Bool { wonPerKm >= 0 && (gcarRates?.isValid ?? true) }
    var summary: String {
        mode == .socar ? "쏘카 · 30km 무료 · 초과 \(wonPerKm.formatted())원/km" : "Gcar · 0~30km \(effectiveGcarRates.first) · 30~100km \(effectiveGcarRates.second) · 100km 초과 \(effectiveGcarRates.third)원/km"
    }
    func won(meters: Double) -> Int {
        guard isValid, meters.isFinite, meters > 0 else { return 0 }
        let km = meters / 1000
        let amount: Double
        if mode == .gcar {
            let rates = effectiveGcarRates
            amount = min(km, 30) * Double(rates.first)
                + min(max(km - 30, 0), 70) * Double(rates.second)
                + max(km - 100, 0) * Double(rates.third)
        } else {
            amount = max(km - 30, 0) * Double(wonPerKm)
        }
        return Int(min(amount.rounded(), Double(Int.max / 2)))
    }
    static func parseRate(_ text: String) -> Int? {
        let text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.utf8.allSatisfy({ (48...57).contains($0) }) else { return nil }
        return Int(text)
    }
}
