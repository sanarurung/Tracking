import SwiftUI
import NMapsMap
import NMapsGeometry

/// A stable native map instance. GPS updates only replace overlay coordinates.
struct NaverRouteMap: UIViewRepresentable {
    let segments: [[RoutePoint]]
    var isHistory = false
    var recenterRequest = 0
    var safetyPoints: [SafetyPoint] = []
    var trackingEnabled = false
    var contentInsets: UIEdgeInsets = .zero

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> NMFNaverMapView {
        let view = NMFNaverMapView(frame: .zero)
        view.showZoomControls = false
        view.showCompass = true
        view.showScaleBar = true
        view.showLocationButton = false
        view.mapView.addCameraDelegate(context.coordinator)
        if !isHistory && trackingEnabled { view.mapView.positionMode = .direction }
        return view
    }

    func updateUIView(_ view: NMFNaverMapView, context: Context) {
        let state = context.coordinator
        if view.mapView.contentInset != contentInsets {
            view.mapView.setContentInset(contentInsets, keepCamera: true)
        }
        if !isHistory, state.trackingEnabled != trackingEnabled {
            view.mapView.positionMode = trackingEnabled ? .direction : .disabled
            state.trackingEnabled = trackingEnabled
        }
        state.updateSafety(safetyPoints, on: view.mapView)
        // Reuse overlays as points arrive; keep outage segments disconnected.
        let routes = segments.filter { $0.count >= 2 }
        while state.lines.count > routes.count {
            state.lines.removeLast().mapView = nil
        }
        for (index, route) in routes.enumerated() {
            let points = route.map { NMGLatLng(lat: $0.coordinate.latitude, lng: $0.coordinate.longitude) }
            if index < state.lines.count {
                state.lines[index].line = NMGLineString(points: points)
            } else if let line = NMFPolylineOverlay(points) {
                line.color = .systemBlue
                line.width = 6
                line.capType = .round
                line.joinType = .round
                line.mapView = view.mapView
                state.lines.append(line)
            }
        }
        if isHistory, !state.fitted {
            let points = segments.flatMap { $0 }.map(\.coordinate)
            if let first = points.first, let last = points.last {
                let start = NMFMarker(position: NMGLatLng(lat: first.latitude, lng: first.longitude))
                start.captionText = "출발"
                start.mapView = view.mapView
                let end = NMFMarker(position: NMGLatLng(lat: last.latitude, lng: last.longitude))
                end.captionText = "도착"
                end.mapView = view.mapView
                state.markers = [start, end]
                let south = points.map(\.latitude).min()! - 0.001
                let north = points.map(\.latitude).max()! + 0.001
                let west = points.map(\.longitude).min()! - 0.001
                let east = points.map(\.longitude).max()! + 0.001
                let bounds = NMGLatLngBounds(southWest: NMGLatLng(lat: south, lng: west),
                                            northEast: NMGLatLng(lat: north, lng: east))
                view.mapView.moveCamera(NMFCameraUpdate(fit: bounds, padding: 36))
                state.fitted = true
            }
        }
        if !isHistory, trackingEnabled, state.recenterRequest != recenterRequest {
            view.mapView.positionMode = .direction
            state.recenterRequest = recenterRequest
        }
    }

    static func dismantleUIView(_ view: NMFNaverMapView, coordinator: Coordinator) {
        view.mapView.removeCameraDelegate(coordinator)
        view.mapView.positionMode = .disabled
        coordinator.safetyMarkers.values.forEach { $0.mapView = nil }
        coordinator.lines.forEach { $0.mapView = nil }
        coordinator.markers.forEach { $0.mapView = nil }
    }

    final class Coordinator: NSObject, NMFMapViewCameraDelegate {
        private var safetyPoints: [SafetyPoint] = []
        private var selectedID: String?
        private var artwork: [String: NMFOverlayImage] = [:]

        func updateSafety(_ points: [SafetyPoint], on map: NMFMapView) {
            safetyPoints = points
            renderSafety(on: map)
        }

        func mapViewCameraIdle(_ mapView: NMFMapView) { renderSafety(on: mapView) }

        private func renderSafety(on map: NMFMapView) {
            let candidates = safetyPoints.map { point -> SafetyDisplayCandidate in
                let position = map.projection.point(from: NMGLatLng(lat: point.latitude, lng: point.longitude))
                return SafetyDisplayCandidate(point: point, x: Double(position.x), y: Double(position.y))
            }
            let area = map.bounds.inset(by: map.contentInset)
            let visible = SafetyDisplayPolicy.visible(candidates, zoom: map.cameraPosition.zoom,
                minX: Double(area.minX), minY: Double(area.minY), maxX: Double(area.maxX), maxY: Double(area.maxY), selectedID: selectedID)
            let ids = Set(visible.map { $0.point.id })
            for id in Array(safetyMarkers.keys) where !ids.contains(id) {
                safetyMarkers.removeValue(forKey: id)?.mapView = nil
            }
            for candidate in visible {
                let point = candidate.point
                let marker: NMFMarker
                if let existing = safetyMarkers[point.id] { marker = existing }
                else {
                    marker = NMFMarker(position: NMGLatLng(lat: point.latitude, lng: point.longitude))
                    let key = "\(point.kind.rawValue)-\(point.speedLimit ?? 0)"
                    if artwork[key] == nil { artwork[key] = NMFOverlayImage(image: SafetyMarkerArtwork.image(for: point)) }
                    marker.iconImage = artwork[key]!
                    marker.width = 32
                    marker.height = 32
                    marker.anchor = CGPoint(x: 0.5, y: 0.5)
                    marker.minZoom = point.kind == .bump ? 16 : 14
                    marker.touchHandler = { [weak self, weak map] _ in
                        guard let self, let map else { return false }
                        self.selectedID = self.selectedID == point.id ? nil : point.id
                        self.renderSafety(on: map)
                        return true
                    }
                    marker.mapView = map
                    safetyMarkers[point.id] = marker
                }
                let selected = selectedID == point.id
                marker.captionText = selected ? point.title : ""
                marker.subCaptionText = selected ? point.speedLimit.map { "등록 제한속도 \($0) km/h" } ?? "" : ""
                marker.zIndex = selected ? 20 : 1
            }
        }

        var lines: [NMFPolylineOverlay] = []
        var markers: [NMFMarker] = []
        var safetyMarkers: [String: NMFMarker] = [:]
        var trackingEnabled = false
        var fitted = false
        var recenterRequest = 0
    }
}
