import SwiftUI
import NMapsMap
import NMapsGeometry

/// A stable native map instance. GPS updates only replace overlay coordinates.
struct NaverRouteMap: UIViewRepresentable {
    let segments: [[RoutePoint]]
    var isHistory = false
    var recenterRequest = 0

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> NMFNaverMapView {
        let view = NMFNaverMapView(frame: .zero)
        view.showZoomControls = false
        view.showCompass = true
        view.showScaleBar = true
        view.showLocationButton = false
        if !isHistory { view.positionMode = .direction }
        return view
    }

    func updateUIView(_ view: NMFNaverMapView, context: Context) {
        let state = context.coordinator
        // Reuse overlays as points arrive; keep outage segments disconnected.
        let routes = segments.filter { $0.count >= 2 }
        while state.lines.count > routes.count {
            state.lines.removeLast().mapView = nil
        }
        for (index, route) in routes.enumerated() {
            let points = route.map { NMGLatLng(lat: $0.coordinate.latitude, lng: $0.coordinate.longitude) }
            if index < state.lines.count {
                state.lines[index].line = NMGLineString(points: points)
            } else if let line = NMFPolylineOverlay(points) {
                line.color = .systemBlue
                line.width = 6
                line.capType = .round
                line.joinType = .round
                line.mapView = view.mapView
                state.lines.append(line)
            }
        }
        if isHistory, !state.fitted {
            let points = segments.flatMap { $0 }.map(\.coordinate)
            if let first = points.first, let last = points.last {
                let start = NMFMarker(position: NMGLatLng(lat: first.latitude, lng: first.longitude))
                start.captionText = "출발"
                start.mapView = view.mapView
                let end = NMFMarker(position: NMGLatLng(lat: last.latitude, lng: last.longitude))
                end.captionText = "도착"
                end.mapView = view.mapView
                state.markers = [start, end]
                let south = points.map(\.latitude).min()! - 0.001
                let north = points.map(\.latitude).max()! + 0.001
                let west = points.map(\.longitude).min()! - 0.001
                let east = points.map(\.longitude).max()! + 0.001
                let bounds = NMGLatLngBounds(southWest: NMGLatLng(lat: south, lng: west),
                                            northEast: NMGLatLng(lat: north, lng: east))
                view.mapView.moveCamera(NMFCameraUpdate(fit: bounds, padding: 36))
                state.fitted = true
            }
        }
        if !isHistory, state.recenterRequest != recenterRequest {
            view.positionMode = .direction
            state.recenterRequest = recenterRequest
        }
    }

    static func dismantleUIView(_ view: NMFNaverMapView, coordinator: Coordinator) {
        view.positionMode = .disabled
        coordinator.lines.forEach { $0.mapView = nil }
        coordinator.markers.forEach { $0.mapView = nil }
    }

    final class Coordinator {
        var lines: [NMFPolylineOverlay] = []
        var markers: [NMFMarker] = []
        var fitted = false
        var recenterRequest = 0
    }
}
