import UIKit

/// Original programmatic road-sign artwork, not extracted APK graphics.
enum SafetyMarkerArtwork {
    static func image(for point: SafetyPoint) -> UIImage {
        UIGraphicsImageRenderer(size: CGSize(width: 64, height: 64)).image { context in
            let circle = UIBezierPath(ovalIn: CGRect(x: 5, y: 5, width: 54, height: 54))
            UIColor.white.setFill(); circle.fill()
            if point.kind == .bump {
                let triangle = UIBezierPath()
                triangle.move(to: CGPoint(x: 32, y: 6))
                triangle.addLine(to: CGPoint(x: 60, y: 56))
                triangle.addLine(to: CGPoint(x: 4, y: 56)); triangle.close()
                UIColor(red:1,green:0.85,blue:0.3,alpha:1).setFill(); triangle.fill()
                UIColor.systemRed.setStroke(); triangle.lineWidth = 4; triangle.stroke()
                let hump = UIBezierPath()
                hump.move(to: CGPoint(x: 16,y:45))
                hump.addLine(to: CGPoint(x: 22,y:45))
                hump.addQuadCurve(to: CGPoint(x:42,y:45),controlPoint:CGPoint(x:32,y:23))
                hump.addLine(to: CGPoint(x:48,y:45))
                UIColor.black.setStroke(); hump.lineWidth=4; hump.stroke()
            } else {
                UIColor.systemRed.setStroke(); circle.lineWidth=5; circle.stroke()
                if let limit = point.speedLimit, point.kind == .camera {
                    let text = String(limit) as NSString
                    let font = UIFont.systemFont(ofSize: limit >= 100 ? 25 : 30,weight:.heavy)
                    let attributes: [NSAttributedString.Key:Any] = [.font:font,.foregroundColor:UIColor.black]
                    let size=text.size(withAttributes:attributes)
                    text.draw(at:CGPoint(x:(64-size.width)/2,y:(64-size.height)/2),withAttributes:attributes)
                } else {
                    // Draw a guaranteed visible glyph; never depend on an optional SF Symbol name.
                    UIColor.black.setFill()
                    if point.kind == .signal {
                        UIBezierPath(roundedRect: CGRect(x:24,y:14,width:16,height:36),cornerRadius:5).fill()
                        for (offset,color) in [(0,UIColor.systemRed),(10,UIColor.systemYellow),(20,UIColor.systemGreen)] {
                            color.setFill()
                            UIBezierPath(ovalIn:CGRect(x:28,y:CGFloat(18+offset),width:8,height:8)).fill()
                        }
                    } else {
                        UIBezierPath(roundedRect:CGRect(x:16,y:23,width:29,height:20),cornerRadius:4).fill()
                        let lens=UIBezierPath();lens.move(to:CGPoint(x:45,y:28));lens.addLine(to:CGPoint(x:53,y:23));lens.addLine(to:CGPoint(x:53,y:43));lens.addLine(to:CGPoint(x:45,y:38));lens.close();lens.fill()
                        UIColor.white.setFill()
                        UIBezierPath(ovalIn:CGRect(x:22,y:29,width:9,height:9)).fill()
                    }
                }
            }
        }
    }
}
