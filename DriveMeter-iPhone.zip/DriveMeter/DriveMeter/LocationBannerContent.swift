import Foundation

struct LocationBannerContent: Decodable, Equatable {
    let source: String
    let district: String?
    let road: String?
    var isValid: Bool { source == "naver" && (district?.count ?? 0) <= 120 && (road?.count ?? 0) <= 120 }
    static func showsRoad(elapsed: TimeInterval) -> Bool {
        guard elapsed.isFinite, elapsed >= 0 else { return false }
        return elapsed.truncatingRemainder(dividingBy: 10) >= 5
    }
    func text(elapsed: TimeInterval) -> String {
        if Self.showsRoad(elapsed: elapsed) { return road.flatMap { $0.isEmpty ? nil : $0 } ?? "도로명 정보 없음" }
        return district.flatMap { $0.isEmpty ? nil : $0 } ?? "지역 정보 없음"
    }
}
