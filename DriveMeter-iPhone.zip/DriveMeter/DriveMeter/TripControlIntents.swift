import AppIntents
import Foundation
#if !WIDGET_EXTENSION
import UIKit
#endif

// LiveActivityIntent executes in the containing app process, sharing its tracker.
enum TripIntentError: Error { case appProcessRequired }

struct PauseTripIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "주행 일시정지"
    static var openAppWhenRun: Bool = false
    static var isDiscoverable: Bool = false
    @Parameter(title: "주행 ID") var tripID: String
    init() {}
    init(tripID: String) { self.tripID = tripID }

    @MainActor
    func perform() async throws -> some IntentResult {
        #if WIDGET_EXTENSION
        throw TripIntentError.appProcessRequired
        #else
        let tracker = TripTracker.shared
        tracker.setAppActive(UIApplication.shared.applicationState == .active)
        await tracker.performLiveControl(.pause, requestedID: tripID)
        #endif
        return .result()
    }
}

struct ResumeTripIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "주행 재개"
    static var openAppWhenRun: Bool = false
    static var isDiscoverable: Bool = false
    @Parameter(title: "주행 ID") var tripID: String
    init() {}
    init(tripID: String) { self.tripID = tripID }

    @MainActor
    func perform() async throws -> some IntentResult {
        #if WIDGET_EXTENSION
        throw TripIntentError.appProcessRequired
        #else
        let tracker = TripTracker.shared
        tracker.setAppActive(UIApplication.shared.applicationState == .active)
        await tracker.performLiveControl(.resume, requestedID: tripID)
        #endif
        return .result()
    }
}

struct FinishTripIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "주행 종료"
    static var openAppWhenRun: Bool = false
    static var isDiscoverable: Bool = false
    @Parameter(title: "주행 ID") var tripID: String
    init() {}
    init(tripID: String) { self.tripID = tripID }

    @MainActor
    func perform() async throws -> some IntentResult {
        #if WIDGET_EXTENSION
        throw TripIntentError.appProcessRequired
        #else
        let tracker = TripTracker.shared
        tracker.setAppActive(UIApplication.shared.applicationState == .active)
        await tracker.performLiveControl(.finish, requestedID: tripID)
        #endif
        return .result()
    }
}

