/// A fresh fix starts/resumes follow; a map gesture suspends it until recenter.
struct MapRecenterPolicy {
    private(set) var didCenter = false
    private(set) var isFollowing = true
    private var handledRequest: Int?
    mutating func userMovedMap() { isFollowing = false }
    mutating func shouldCenter(request: Int, locationFresh: Bool) -> Bool {
        guard locationFresh else { return false }
        if !didCenter || handledRequest != request {
            didCenter = true
            handledRequest = request
            isFollowing = true
        }
        return isFollowing
    }
}
