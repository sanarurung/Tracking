/// Consume a camera request only after a fresh location is available.
struct MapRecenterPolicy {
    private(set) var didCenter = false
    private var handledRequest: Int?
    mutating func shouldCenter(request: Int, locationFresh: Bool) -> Bool {
        guard locationFresh, !didCenter || handledRequest != request else { return false }
        didCenter = true
        handledRequest = request
        return true
    }
}
