import Foundation
import CoreLocation
import Combine
import CoreMotion

@MainActor
final class TripTracker: NSObject, ObservableObject, CLLocationManagerDelegate {
    static let shared = TripTracker()

    enum Phase { case ready, recording, paused, finished }
    @Published private(set) var phase: Phase = .ready
    @Published private(set) var approachWarning: SafetyApproachWarning?
    @Published var voiceGuidanceEnabled = UserDefaults.standard.object(forKey: "voice-guidance") as? Bool ?? true {
        didSet {
            UserDefaults.standard.set(voiceGuidanceEnabled, forKey: "voice-guidance")
            if !voiceGuidanceEnabled { voiceAnnouncer.stop() }
        }
    }
    private var approachEngine = SafetyApproachEngine()
    private let voiceAnnouncer = SafetyVoiceAnnouncer()
    @Published private(set) var currentLocation: CLLocation?
    @Published private(set) var locationAccessGranted = false
    @Published private(set) var nearbySafety: [NearbySafetyPoint] = []
    @Published private(set) var safetyWarning: String?
    private var safetyIndex = SafetyIndex(points: [])
    private var lastSafetyLocation: CLLocation?
    private var appActive = true
    @Published private(set) var speedReading: SpeedReading?
    @Published private(set) var meters = 0.0
    @Published private(set) var estimatedMeters = 0.0
    @Published private(set) var fusedMeters = 0.0
    @Published private(set) var isEstimating = false
    @Published private(set) var isSensorFusing = false
    @Published private(set) var segments: [[RoutePoint]] = []
    @Published private(set) var history: [TripRecord] = []
    @Published private(set) var historyWarning: String?
    @Published private(set) var needsArchiveRetry = false
    @Published private(set) var status = "시작을 누르면 GPS와 센서 측정을 시작합니다"
    @Published var problem: String?
    private let manager = CLLocationManager()
    private let motion = CMMotionManager()
    private var fusion = DistanceFusion()
    private var speedFusion = SpeedFusion()
    private var lastSpeedPublish = Date.distantPast
    private var lastTrustedFix: CLLocation?
    private var routeAnchor: CLLocation?
    private var positionRecoveryPending = false
    private var lastValidMotion = Date.distantPast
    private var sensorReady = false
    private var tripID = UUID()
    private let liveActivity = TripLiveActivityController()
    @Published private(set) var liveActivityNotice: String?
    private var startedAt: Date?
    private var endedAt: Date?
    private var wantsToStart = false
    private var lastSave = Date.distantPast
    private var lastStatusUpdate = Date.distantPast
    private let saveURL = URL.documentsDirectory.appending(path: "current-trip.json")
    private let historyStore = TripHistoryStore(directory: URL.documentsDirectory.appending(path: "Trips"))
    @Published private(set) var farePolicy: TripFarePolicy = .gcar
    var fare: Int { farePolicy.won(meters: meters) }

    private override init() {
        super.init()
        manager.delegate = self
        manager.activityType = .automotiveNavigation
        manager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        manager.distanceFilter = kCLDistanceFilterNone
        manager.pausesLocationUpdatesAutomatically = false
        manager.showsBackgroundLocationIndicator = true
        loadSafetyData()
        reloadHistory()
        restore()
        liveActivity.onNotice = { [weak self] text in self?.liveActivityNotice = text }
        syncLiveActivity(force: true)
    }

    private func loadSafetyData() {
        do {
            var points: [SafetyPoint] = []
            for name in ["SafetyCameras", "SafetyBumps"] {
                guard let url = Bundle.main.url(forResource: name, withExtension: "json") else {
                    throw CocoaError(.fileNoSuchFile)
                }
                points += try JSONDecoder().decode([SafetyPoint].self, from: Data(contentsOf: url))
            }
            safetyIndex = SafetyIndex(points: points)
        } catch { safetyWarning = "안전운전 데이터를 불러오지 못했습니다" }
    }

    func prepareMapLocation(showError: Bool = false) {
        guard CLLocationManager.locationServicesEnabled() else {
            locationAccessGranted = false
            if showError { problem = "설정에서 위치 서비스를 켜 주세요." }
            return
        }
        switch manager.authorizationStatus {
        case .notDetermined:
            manager.requestWhenInUseAuthorization()
        case .authorizedAlways, .authorizedWhenInUse:
            locationAccessGranted = true
            if phase != .recording && appActive {
                manager.allowsBackgroundLocationUpdates = false
                manager.startUpdatingLocation()
                ensureMotionUpdates()
            }
        case .denied, .restricted:
            locationAccessGranted = false
            if showError { problem = "내 위치와 주변 정보를 표시하려면 설정에서 위치 권한을 허용해 주세요." }
        @unknown default: break
        }
    }

    func setAppActive(_ active: Bool) {
        appActive = active
        if !active { approachWarning = nil; voiceAnnouncer.stop() }
        if active { prepareMapLocation() }
        else if phase != .recording {
            manager.stopUpdatingLocation()
            motion.stopDeviceMotionUpdates()
            speedFusion.invalidateMotion()
            speedReading = nil
            sensorReady = false
            lastValidMotion = .distantPast
        }
        syncLiveActivity(force: true, allowStart: active)
    }

    private func updateMapLocation(_ location: CLLocation) {
        currentLocation = location
        if abs(location.timestamp.timeIntervalSinceNow) < 2 {
            speedFusion.observeGPS(speed: location.speed, speedAccuracy: location.speedAccuracy, course: location.course,
                horizontalAccuracy: location.horizontalAccuracy, at: location.timestamp.timeIntervalSinceReferenceDate,
                motionAvailable: sensorReady && Date().timeIntervalSince(lastValidMotion) < 0.5)
        }
        publishSpeed(now: Date(), force: true)
        if appActive {
            let nearby = safetyIndex.nearby(location, radius: 2_000, limit: 500)
            let decision = approachEngine.update(location: location, points: nearby.map(\.point), now: Date(), speedOverride: speedReading?.metresPerSecond)
            approachWarning = decision.warning
            if voiceGuidanceEnabled, let warning = decision.announcement { voiceAnnouncer.announce(warning) }
        }
        if let last = lastSafetyLocation, location.distance(from: last) < 50,
           location.timestamp.timeIntervalSince(last.timestamp) < 20 { return }
        lastSafetyLocation = location
        nearbySafety = safetyIndex.nearby(location)
    }

    func startSocar(rate: Int) {
        guard phase == .ready, rate >= 0 else { return }
        farePolicy = TripFarePolicy(mode: .socar, wonPerKm: rate)
        start()
    }

    func startGcar() {
        guard phase == .ready else { return }
        farePolicy = .gcar
        start()
    }

    func start() {
        guard phase == .ready || phase == .paused else { return }
        guard CLLocationManager.locationServicesEnabled() else {
            problem = "설정에서 위치 서비스를 켜 주세요."
            return
        }
        switch manager.authorizationStatus {
        case .notDetermined:
            wantsToStart = true
            manager.requestWhenInUseAuthorization()
        case .authorizedAlways, .authorizedWhenInUse:
            wantsToStart = false
            if startedAt == nil { startedAt = Date() }
            routeAnchor = nil
            segments.append([])
            phase = .recording
            status = "정확한 GPS 위치를 찾고 있습니다"
            manager.allowsBackgroundLocationUpdates = true
            manager.startUpdatingLocation()
            startMotion()
            persist()
            syncLiveActivity(force: true, allowStart: appActive)
        case .denied, .restricted:
            problem = "설정에서 위치 권한과 정확한 위치를 켜 주세요."
        @unknown default: break
        }
    }

    func pause() {
        guard phase == .recording else { return }
        commitSensorTail()
        stopGPS()
        phase = .paused
        prepareMapLocation()
        status = "일시정지 · 이동거리 적립이 멈췄습니다"
        persist()
        syncLiveActivity(force: true)
    }

    func finish() {
        guard phase != .ready else { return }
        wantsToStart = false
        if phase == .recording { commitSensorTail() }
        stopGPS()
        if endedAt == nil { endedAt = Date() }
        phase = .finished
        prepareMapLocation()
        persist()
        _ = archiveCurrentTrip()
        syncLiveActivity(force: true)
    }

    func retryArchive() { if phase == .finished { _ = archiveCurrentTrip() } }

    func reset() {
        // Do not clear the recoverable snapshot before the archive is safe.
        if phase == .finished && !archiveCurrentTrip() { return }
        wantsToStart = false
        stopGPS()
        tripID = UUID()
        farePolicy = .gcar
        startedAt = nil
        endedAt = nil
        meters = 0
        estimatedMeters = 0
        fusedMeters = 0
        segments = []
        needsArchiveRetry = false
        phase = .ready
        prepareMapLocation()
        status = "시작을 누르면 GPS와 센서 측정을 시작합니다"
        persist()
        syncLiveActivity(force: true)
    }

    private func archiveCurrentTrip() -> Bool {
        if history.contains(where: { $0.id == tripID }) {
            needsArchiveRetry = false
            status = "주행 완료 · 주행 기록에 저장했습니다"
            return true
        }
        let record = TripRecord(id: tripID, startedAt: startedAt, endedAt: endedAt, savedAt: Date(),
                                meters: meters, estimatedMeters: estimatedMeters, fusedMeters: fusedMeters,
                                fareWon: fare, segments: segments, calculationVersion: farePolicy.mode == .socar ? "socar-fixed-30free-v1" : "gps-motion-v2", farePolicy: farePolicy)
        do {
            try historyStore.save(record)
            history.removeAll { $0.id == record.id }
            history.append(record)
            history.sort { ($0.endedAt ?? $0.savedAt) > ($1.endedAt ?? $1.savedAt) }
            needsArchiveRetry = false
            status = "주행 완료 · 주행 기록에 저장했습니다"
            return true
        } catch {
            needsArchiveRetry = true
            status = "기록 보관 실패 · 저장 재시도가 필요합니다"
            problem = "주행 기록을 보관하지 못했습니다. 현재 기록은 유지됩니다. 저장 재시도 성공 후 새 주행을 시작해 주세요."
            return false
        }
    }

    func reloadHistory() {
        do {
            let result = try historyStore.load()
            history = result.records
            historyWarning = result.unreadable > 0 ? "기록 \(result.unreadable)건을 읽지 못했습니다. 원본은 보존했습니다." : nil
        } catch { historyWarning = "기록 목록을 읽지 못했습니다. 다시 시도해 주세요." }
    }

    func persist() {
        let snapshot = TripSnapshot(meters: meters, segments: segments, finished: phase == .finished,
                                    estimatedMeters: estimatedMeters, id: tripID, startedAt: startedAt,
                                    endedAt: endedAt, fusedMeters: fusedMeters, farePolicy: farePolicy)
        do {
            try JSONEncoder().encode(snapshot).write(to: saveURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            lastSave = Date()
        } catch { problem = "현재 주행 저장 실패 · 저장 공간을 확인해 주세요. 앱 종료 시 최근 기록이 유실될 수 있습니다." }
    }

    private func restore() {
        guard FileManager.default.fileExists(atPath: saveURL.path) else { return }
        do {
            let saved = try JSONDecoder().decode(TripSnapshot.self, from: Data(contentsOf: saveURL))
            guard saved.meters.isFinite, saved.meters >= 0,
                  saved.segments.joined().allSatisfy({ (-90...90).contains($0.latitude) && (-180...180).contains($0.longitude) }) else {
                throw CocoaError(.fileReadCorruptFile)
            }
            guard saved.farePolicy?.isValid ?? true else { throw CocoaError(.fileReadCorruptFile) }
            farePolicy = saved.farePolicy ?? .gcar
            meters = saved.meters
            estimatedMeters = bounded(saved.estimatedMeters)
            fusedMeters = bounded(saved.fusedMeters)
            tripID = saved.id ?? TripHistoryStore.legacyID(for: saved)
            startedAt = saved.startedAt
            endedAt = saved.endedAt
            segments = saved.segments.filter { !$0.isEmpty }
            if saved.finished {
                phase = .finished
                persist() // Stable ID makes migration/retries idempotent.
                _ = archiveCurrentTrip()
            } else if !segments.isEmpty || meters > 0 || startedAt != nil {
                phase = .paused
                status = "기록 복원 완료 · 계속하려면 재개를 눌러 주세요"
            }
        } catch { problem = "현재 주행을 읽지 못했습니다. 과거 주행 기록은 별도로 보관됩니다." }
    }

    private func bounded(_ value: Double?) -> Double {
        guard let value, value.isFinite else { return 0 }
        return min(meters, max(0, value))
    }

    private func commitSensorTail() {
        let tail = fusion.finishInterval(at: Date().timeIntervalSinceReferenceDate)
        meters += tail
        estimatedMeters += tail
    }

    private func stopGPS() {
        speedReading = nil
        speedFusion = SpeedFusion()
        lastSpeedPublish = .distantPast
        manager.stopUpdatingLocation()
        manager.allowsBackgroundLocationUpdates = false
        motion.stopDeviceMotionUpdates()
        fusion = DistanceFusion()
        lastTrustedFix = nil
        routeAnchor = nil
        positionRecoveryPending = false
        isEstimating = false
        isSensorFusing = false
        sensorReady = false
        lastValidMotion = .distantPast
    }

    private func startMotion() {
        fusion = DistanceFusion()
        lastTrustedFix = nil
        lastValidMotion = .distantPast
        ensureMotionUpdates()
    }

    private func publishSpeed(now: Date, force: Bool = false) {
        guard force || now.timeIntervalSince(lastSpeedPublish) >= 0.1 else { return }
        speedReading = speedFusion.reading(at: now.timeIntervalSinceReferenceDate)
        lastSpeedPublish = now
        syncLiveActivity()
    }

    func performLiveControl(_ command: TripControlCommand, requestedID: String) async {
        let livePhase: TripLiveState.Phase? = phase == .recording ? .recording : phase == .paused ? .paused : phase == .finished ? .finished : nil
        guard TripControlPolicy.accepted(command, requestedID: requestedID, currentID: tripID, phase: livePhase) else {
            syncLiveActivity(force: true)
            await liveActivity.flush()
            return
        }
        switch command {
        case .pause: pause()
        case .resume: start()
        case .finish: finish()
        }
        // Do not return the intent before its visible update/end has completed.
        await liveActivity.flush()
    }

    private func syncLiveActivity(force: Bool = false, allowStart: Bool = false) {
        if phase == .ready {
            if force { liveActivity.submit(id: tripID, state: nil, allowStart: false, force: true) }
            return
        }
        let now = Date()
        let speed = speedReading?.kilometresPerHour(at: now)
        let expiry = speedReading.map { reading in
            min(reading.timestamp.addingTimeInterval(reading.source == .gps ? 5 : 1), reading.expiresAt ?? .distantFuture)
        }
        let state = TripLiveState(phase: phase == .recording ? .recording : phase == .paused ? .paused : .finished,
            meters: meters, fareWon: fare, speedKmh: speed, speedValidUntil: expiry, now: now)
        liveActivity.submit(id: tripID, state: state, allowStart: allowStart && appActive, force: force)
    }

    private func ensureMotionUpdates() {
        guard !motion.isDeviceMotionActive else { return }
        sensorReady = motion.isDeviceMotionAvailable && CMMotionManager.availableAttitudeReferenceFrames().contains(.xTrueNorthZVertical)
        guard sensorReady else { return }
        motion.deviceMotionUpdateInterval = 0.05
        motion.startDeviceMotionUpdates(using: .xTrueNorthZVertical, to: .main) { [weak self] data, error in
            guard let self, self.phase == .recording || self.appActive else { return }
            guard let data, error == nil else {
                self.sensorReady = false
                self.fusion.invalidateMotion()
                self.speedFusion.invalidateMotion()
                self.publishSpeed(now: Date(), force: true)
                self.isEstimating = false
                self.isSensorFusing = false
                if self.phase == .recording { self.status = "모션 센서 사용 불가 · GPS로만 기록합니다" }
                return
            }
            self.consumeMotion(data)
        }
    }

    private func consumeMotion(_ data: CMDeviceMotion) {
        let now = Date()
        let rotation = data.rotationRate
        guard data.magneticField.accuracy != .uncalibrated,
              sqrt(rotation.x * rotation.x + rotation.y * rotation.y + rotation.z * rotation.z) < 1.5 else {
            fusion.invalidateMotion()
            speedFusion.invalidateMotion()
            publishSpeed(now: now, force: true)
            isSensorFusing = false
            isEstimating = false
            lastValidMotion = .distantPast
            return
        }
        lastValidMotion = now
        sensorReady = true
        let a = data.userAcceleration
        let r = data.attitude.rotationMatrix
        let north = (r.m11 * a.x + r.m21 * a.y + r.m31 * a.z) * 9.80665
        let west = (r.m12 * a.x + r.m22 * a.y + r.m32 * a.z) * 9.80665
        speedFusion.sample(north: north, west: west, at: now.timeIntervalSinceReferenceDate, sensorTime: data.timestamp)
        publishSpeed(now: now)
        guard phase == .recording else { return }
        let added = fusion.sample(north: north, west: west, at: now.timeIntervalSinceReferenceDate, sensorTime: data.timestamp)
        if added > 0 {
            meters += added
            estimatedMeters += added
            isEstimating = true
            isSensorFusing = false
            if now.timeIntervalSince(lastStatusUpdate) >= 1 {
                status = "GPS 음영 · 센서로 거리 추정 중"
                lastStatusUpdate = now
            }
            if now.timeIntervalSince(lastSave) >= 5 { persist() }
        } else if fusion.interrupted, let fix = lastTrustedFix,
                  now.timeIntervalSince(fix.timestamp) >= DistanceFusion.outageThreshold {
            isEstimating = false
            isSensorFusing = false
            status = "센서 추정 중지 · 3분 한도 또는 센서 수신 끊김"
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            locationAccessGranted = true
            if wantsToStart { start() } else { prepareMapLocation() }
        case .denied, .restricted:
            locationAccessGranted = false
            approachWarning = nil
            voiceAnnouncer.stop()
            currentLocation = nil
            nearbySafety = []
            lastSafetyLocation = nil
            wantsToStart = false
            if phase == .recording { pause() }
            status = "위치 권한이 필요합니다"
        default: break
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let preview = locations.filter({ CLLocationCoordinate2DIsValid($0.coordinate)
            && (0...100).contains($0.horizontalAccuracy) && abs($0.timestamp.timeIntervalSinceNow) < 10
        }).max(by: { $0.timestamp < $1.timestamp }) { updateMapLocation(preview) }
        guard phase == .recording else { return }
        guard let location = locations.filter({
            CLLocationCoordinate2DIsValid($0.coordinate) && (0...30).contains($0.horizontalAccuracy)
                && abs($0.timestamp.timeIntervalSinceNow) < 5
        }).max(by: { $0.timestamp < $1.timestamp }) else { return }
        if let previous = lastTrustedFix {
            let dt = location.timestamp.timeIntervalSince(previous.timestamp)
            guard dt > 0, dt > 30 || location.distance(from: previous) / dt <= 70 else { return }
        }
        let now = Date()
        let distance = positionRecoveryPending ? nil : lastTrustedFix.map { location.distance(from: $0) }
        let result = fusion.observeGPS(distance: distance, speed: location.speed,
                                        speedAccuracy: location.speedAccuracy, course: location.course,
                                        horizontalAccuracy: location.horizontalAccuracy,
                                        at: now.timeIntervalSinceReferenceDate,
                                        motionAvailable: sensorReady && now.timeIntervalSince(lastValidMotion) < 0.5)
        meters += result.meters
        estimatedMeters += result.estimatedMeters
        if result.usesMotion { fusedMeters += result.meters }
        isEstimating = false
        isSensorFusing = result.usesMotion
        positionRecoveryPending = result.rejectsCoordinate
        publishSpeed(now: now, force: true)
        lastTrustedFix = location
        if result.breaksRoute || result.rejectsCoordinate {
            routeAnchor = nil
            if segments.last?.isEmpty == false { segments.append([]) }
        }
        if !result.rejectsCoordinate && (routeAnchor == nil || location.distance(from: routeAnchor!) >= 5) {
            if segments.isEmpty { segments.append([]) }
            segments[segments.count - 1].append(RoutePoint(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude))
            routeAnchor = location
        }
        status = result.usesMotion ? "GPS + 가속도 센서 보정 중 · ±\(Int(location.horizontalAccuracy))m"
            : "GPS 기록 중 · 정확도 ±\(Int(location.horizontalAccuracy))m"
        if now.timeIntervalSince(lastSave) >= 5 { persist() }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        guard phase == .recording else { return }
        if let error = error as? CLError, error.code == .denied {
            pause()
            problem = "위치 접근이 중단되었습니다. 설정에서 위치 권한을 확인해 주세요."
        } else if !isEstimating { status = "GPS 신호 대기 · 센서 보정을 계속합니다" }
    }
}
