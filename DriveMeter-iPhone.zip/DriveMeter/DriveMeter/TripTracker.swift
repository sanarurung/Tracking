import Foundation
import CoreLocation
import Combine
import CoreMotion

struct RoutePoint: Codable {
    let latitude: Double
    let longitude: Double
    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}

struct TripSnapshot: Codable {
    var meters: Double
    var segments: [[RoutePoint]]
    var finished: Bool
    var estimatedMeters: Double?
}

@MainActor
final class TripTracker: NSObject, ObservableObject, CLLocationManagerDelegate {
    enum Phase { case ready, recording, paused, finished }
    @Published private(set) var phase: Phase = .ready
    @Published private(set) var meters = 0.0
    @Published private(set) var estimatedMeters = 0.0
    @Published private(set) var isEstimating = false
    @Published private(set) var segments: [[RoutePoint]] = []
    @Published private(set) var status = "시작을 누르면 GPS 측정을 시작합니다"
    @Published var problem: String?

    private let manager = CLLocationManager()
    private let motion = CMMotionManager()
    private var inertial = InertialDistance()
    private var lastTrustedFix: CLLocation?
    private var lastMotionPublication = Date.distantPast
    private var sensorReady = false
    private var motionClock: Double?
    private var anchor: CLLocation?
    private var wantsToStart = false
    private var lastSave = Date.distantPast
    private let saveURL = URL.documentsDirectory.appending(path: "current-trip.json")
    var fare: Int { FareCalculator.won(meters: meters) }
    var hasTrip: Bool { phase != .ready || meters > 0 || !segments.isEmpty }

    override init() {
        super.init()
        manager.delegate = self
        manager.activityType = .automotiveNavigation
        manager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        manager.distanceFilter = 5
        manager.pausesLocationUpdatesAutomatically = false
        manager.showsBackgroundLocationIndicator = true
        restore()
    }

    func start() {
        guard phase == .ready || phase == .paused else { return }
        guard CLLocationManager.locationServicesEnabled() else {
            problem = "iPhone 설정 > 개인정보 보호 및 보안 > 위치 서비스에서 위치 서비스를 켜 주세요."
            return
        }
        switch manager.authorizationStatus {
        case .notDetermined:
            wantsToStart = true
            manager.requestWhenInUseAuthorization()
        case .authorizedAlways, .authorizedWhenInUse:
            wantsToStart = false
            anchor = nil
            segments.append([])
            phase = .recording
            status = "정확한 GPS 위치를 찾고 있습니다"
            manager.allowsBackgroundLocationUpdates = true
            manager.startUpdatingLocation()
            startMotion()
            persist()
        case .denied, .restricted:
            problem = "위치 접근이 허용되지 않았습니다. 설정에서 이 앱의 위치 권한과 정확한 위치를 켜 주세요."
        @unknown default: break
        }
    }

    func pause() {
        guard phase == .recording else { return }
        stopGPS()
        phase = .paused
        status = "일시정지 · 이동거리 적립이 멈췄습니다"
        persist()
    }

    func finish() {
        wantsToStart = false
        stopGPS()
        phase = .finished
        status = "주행 완료 · 최종 요금입니다"
        persist()
    }

    func reset() {
        wantsToStart = false
        stopGPS()
        meters = 0
        estimatedMeters = 0
        segments = []
        phase = .ready
        status = "시작을 누르면 GPS 측정을 시작합니다"
        persist()
    }

    func persist() {
        let snapshot = TripSnapshot(meters: meters, segments: segments, finished: phase == .finished, estimatedMeters: estimatedMeters)
        do {
            try JSONEncoder().encode(snapshot).write(to: saveURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            lastSave = Date()
        } catch {
            problem = "주행 기록을 저장하지 못했습니다. 앱을 종료하면 최근 기록이 유실될 수 있습니다."
        }
    }

    private func restore() {
        guard FileManager.default.fileExists(atPath: saveURL.path) else { return }
        do {
            let saved = try JSONDecoder().decode(TripSnapshot.self, from: Data(contentsOf: saveURL))
            guard saved.meters.isFinite, saved.meters >= 0,
                  saved.segments.joined().allSatisfy({ (-90...90).contains($0.latitude) && (-180...180).contains($0.longitude) }) else {
                throw CocoaError(.fileReadCorruptFile)
            }
            meters = saved.meters
            let estimate = saved.estimatedMeters ?? 0
            estimatedMeters = estimate.isFinite ? min(saved.meters, max(0, estimate)) : 0
            segments = saved.segments.filter { !$0.isEmpty }
            if saved.finished {
                phase = .finished
                status = "저장된 주행 완료 기록"
            } else if !segments.isEmpty || meters > 0 {
                phase = .paused
                status = "기록 복원 완료 · 계속하려면 재개를 눌러 주세요"
            }
        } catch {
            problem = "저장된 주행 기록을 읽지 못했습니다. 새 주행을 시작할 수 있습니다."
        }
    }

    private func stopGPS() {
        manager.stopUpdatingLocation()
        manager.allowsBackgroundLocationUpdates = false
        motion.stopDeviceMotionUpdates()
        inertial = InertialDistance()
        lastTrustedFix = nil
        isEstimating = false
        sensorReady = false
        motionClock = nil
        anchor = nil
    }

    private func startMotion() {
        inertial = InertialDistance()
        lastTrustedFix = nil
        motionClock = nil
        sensorReady = motion.isDeviceMotionAvailable && CMMotionManager.availableAttitudeReferenceFrames().contains(.xTrueNorthZVertical)
        guard sensorReady else { return }
        motion.deviceMotionUpdateInterval = 0.05
        motion.startDeviceMotionUpdates(using: .xTrueNorthZVertical, to: .main) { [weak self] data, error in
            guard let self, self.phase == .recording else { return }
            guard let data, error == nil else {
                self.sensorReady = false
                self.inertial = InertialDistance()
                self.isEstimating = false
                self.status = "모션 센서 사용 불가 · GPS로만 기록합니다"
                return
            }
            self.consumeMotion(data)
        }
    }

    private func consumeMotion(_ data: CMDeviceMotion) {
        motionClock = data.timestamp
        // Transpose rotates device-space acceleration into the reference frame.
        let a = data.userAcceleration
        let r = data.attitude.rotationMatrix
        let north = (r.m11 * a.x + r.m21 * a.y + r.m31 * a.z) * 9.80665
        let west = (r.m12 * a.x + r.m22 * a.y + r.m32 * a.z) * 9.80665
        let now = Date()
        let added = inertial.sample(north: north, west: west, at: data.timestamp)
        if added > 0 {
            meters += added
            estimatedMeters += added
            isEstimating = true
            if now.timeIntervalSince(lastMotionPublication) >= 1 {
                status = "GPS 음영 · 가속도계로 거리 추정 중"
                lastMotionPublication = now
            }
            if now.timeIntervalSince(lastSave) >= 5 { persist() }
        } else if inertial.interrupted, let fix = lastTrustedFix,
                  now.timeIntervalSince(fix.timestamp) >= InertialDistance.outageThreshold {
            isEstimating = false
            status = "센서 추정 중지 · 3분 한도 또는 센서 수신 끊김"
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            if wantsToStart { start() }
        case .denied, .restricted:
            wantsToStart = false
            if phase == .recording { pause() }
            status = "위치 권한이 필요합니다"
        default: break
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard phase == .recording else { return }
        for location in locations.sorted(by: { $0.timestamp < $1.timestamp }) {
            // Ignore stale fixes, approximate positions, and physically implausible jumps.
            guard CLLocationCoordinate2DIsValid(location.coordinate),
                  location.horizontalAccuracy >= 0, location.horizontalAccuracy <= 30,
                  abs(location.timestamp.timeIntervalSinceNow) < 5 else {
                if !isEstimating { status = "GPS 신호 대기 · 정확한 위치 설정을 확인해 주세요" }
                continue
            }
            if let previousFix = lastTrustedFix {
                let elapsed = location.timestamp.timeIntervalSince(previousFix.timestamp)
                guard elapsed > 0 else { continue }
                if elapsed <= 30 && location.distance(from: previousFix) / elapsed > 70 { continue }
            }
            // A returning fix starts a separate GPS line. Estimated distance is
            // already included, so never add the GPS chord across this outage.
            let recoveredFromOutage = inertial.usedFallback || inertial.interrupted
                || lastTrustedFix.map { location.timestamp.timeIntervalSince($0.timestamp) >= InertialDistance.outageThreshold } == true
            if recoveredFromOutage {
                segments.append([])
                anchor = nil
            }
            lastTrustedFix = location
            isEstimating = false
            if sensorReady, let motionClock {
                inertial.seed(speed: location.speed, course: location.course, at: motionClock)
            }
            if let previous = anchor {
                let seconds = location.timestamp.timeIntervalSince(previous.timestamp)
                guard seconds > 0 else { continue }
                // Avoid charging a straight-line shortcut across a long signal outage.
                if seconds > 30 {
                    segments.append([])
                    anchor = nil
                } else {
                    let distance = location.distance(from: previous)
                    guard distance / seconds <= 70 else { continue }
                    let threshold = max(5, (location.horizontalAccuracy + previous.horizontalAccuracy) / 2)
                    guard distance >= threshold else { continue }
                    if location.speed >= 0 && location.speed < 0.8 { continue }
                    meters += distance
                }
            }
            anchor = location
            if segments.isEmpty { segments.append([]) }
            segments[segments.count - 1].append(RoutePoint(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude))
            status = sensorReady ? "GPS 기록 중 · 정확도 ±\(Int(location.horizontalAccuracy))m" : "GPS 기록 중 · 센서 추정 사용 불가"
            if Date().timeIntervalSince(lastSave) >= 5 { persist() }
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        guard phase == .recording else { return }
        if let error = error as? CLError, error.code == .denied {
            pause()
            problem = "위치 접근이 중단되었습니다. 설정에서 위치 권한을 확인해 주세요."
        } else {
            if !isEstimating { status = "GPS 신호 대기 · 수신되면 자동으로 계속합니다" }
        }
    }
}
