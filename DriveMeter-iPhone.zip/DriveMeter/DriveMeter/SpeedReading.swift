import Foundation

/// GPS speed is metres/second. An unknown or stale reading is not a stop.
struct SpeedReading {
    enum Source { case gps, gpsMotion, inertial }
    let metresPerSecond: Double
    let accuracy: Double
    let timestamp: Date
    var source: Source = .gps
    var expiresAt: Date? = nil

    func kilometresPerHour(at now: Date) -> Double? {
        let age = now.timeIntervalSince(timestamp)
        guard metresPerSecond.isFinite, (0...70).contains(metresPerSecond),
              accuracy.isFinite, accuracy >= 0, (source != .gps || accuracy <= 5),
              age >= -1, age <= (source == .gps ? 5 : 1),
              expiresAt.map({ now <= $0 }) ?? true else { return nil }
        return metresPerSecond * 3.6
    }
}
