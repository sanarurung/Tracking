import Foundation

/// GPS speed is metres/second. An unknown or stale reading is not a stop.
struct SpeedReading {
    let metresPerSecond: Double
    let accuracy: Double
    let timestamp: Date

    func kilometresPerHour(at now: Date) -> Double? {
        let age = now.timeIntervalSince(timestamp)
        guard metresPerSecond.isFinite, (0...70).contains(metresPerSecond),
              accuracy.isFinite, (0...5).contains(accuracy),
              (-1...5).contains(age) else { return nil }
        return metresPerSecond * 3.6
    }
}
