import SwiftUI

struct MainTabView: View {
    @ObservedObject var tracker: TripTracker
    var body: some View {
        TabView {
            Tab("주행", systemImage: "map") {
                ContentView(tracker: tracker)
            }
            Tab("주행 기록", systemImage: "clock.arrow.circlepath") {
                TripHistoryView(tracker: tracker)
            }
        }.tint(.blue)
    }
}
