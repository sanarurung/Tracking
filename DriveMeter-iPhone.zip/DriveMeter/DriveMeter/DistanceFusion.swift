import Foundation

struct FusedDistanceUpdate {
    var meters = 0.0
    var estimatedMeters = 0.0
    var usesMotion = false
    var breaksRoute = false
    var rejectsCoordinate = false
}

/// A bounded complementary distance filter with scalar velocity uncertainty.
/// GPS remains the absolute reference. Motion predicts BETWEEN fixes, never adds
/// a second independent odometer on top of the same GPS interval.
struct DistanceFusion {
    static let outageThreshold = 5.0
    static let maximumOutage = 180.0
    private(set) var speed = 0.0
    private(set) var usedFallback = false
    private(set) var interrupted = false
    private var gpsTime: Double?
    private var sampleTime: Double?
    private var sampleClock: Double?
    private var heading: Double?
    private var predictionEnabled = false
    private var pendingMeters = 0.0
    private var coveredSeconds = 0.0
    private var velocityVariance = 1.0
    private var previousGPSSpeed: Double?
    private var previousSpeedAccuracy = 10.0
    private var acceleration = 0.0
    private var bias = 0.0
    private var accelerationIntegral = 0.0

    mutating func invalidateMotion() {
        predictionEnabled = false
        interrupted = true
        pendingMeters = 0
        coveredSeconds = 0
    }

    mutating func finishInterval(at time: Double) -> Double {
        guard predictionEnabled, !interrupted, let gpsTime,
              (0...Self.maximumOutage).contains(time - gpsTime) else { return 0 }
        let result = pendingMeters
        pendingMeters = 0
        return result
    }

    mutating func sample(north: Double, west: Double, at time: Double, sensorTime: Double? = nil) -> Double {
        let clock = sensorTime ?? time
        defer { sampleTime = time; sampleClock = clock }
        guard north.isFinite, west.isFinite, time.isFinite, clock.isFinite,
              predictionEnabled, let gpsTime, let heading,
              let previousClock = sampleClock else { return 0 }
        let dt = clock - previousClock
        let age = time - gpsTime
        guard dt > 0 else { return 0 }
        guard dt <= 0.5, age >= 0, age <= Self.maximumOutage else {
            invalidateMotion()
            return 0
        }
        let raw = north * cos(heading) - west * sin(heading)
        let alpha = 1 - exp(-dt / 0.3)
        acceleration += alpha * (raw - bias - acceleration)
        let a = abs(acceleration) < 0.06 ? 0 : min(3, max(-5, acceleration))
        let previousSpeed = speed
        speed = min(70, max(0, speed + a * dt))
        velocityVariance = min(100, velocityVariance + 0.45 * 0.45 * dt)
        pendingMeters += (previousSpeed + speed) * 0.5 * dt
        coveredSeconds += dt
        accelerationIntegral += raw * dt
        guard age >= Self.outageThreshold else { return 0 }
        usedFallback = true
        let result = pendingMeters
        pendingMeters = 0
        return result
    }

    mutating func observeGPS(distance: Double?, speed gpsSpeed: Double, speedAccuracy: Double,
                             course: Double, horizontalAccuracy: Double,
                             at time: Double, motionAvailable: Bool) -> FusedDistanceUpdate {
        var result = FusedDistanceUpdate()
        guard time.isFinite, horizontalAccuracy.isFinite, horizontalAccuracy >= 0 else { return result }
        let elapsed = gpsTime.map { time - $0 }
        if let elapsed, elapsed <= 0 { return result }
        let validSpeed = gpsSpeed.isFinite && (0...70).contains(gpsSpeed)
            && speedAccuracy.isFinite && (0...5).contains(speedAccuracy)
        let oldHeading = heading
        let newHeading: Double? = course.isFinite && (0..<360).contains(course) ? course * .pi / 180 : heading
        let normalPrediction = predictionEnabled && !interrupted && motionAvailable
            && elapsed.map { coveredSeconds >= $0 * 0.8 && coveredSeconds <= $0 * 1.25 } == true

        if let dt = elapsed {
            if usedFallback || dt >= Self.outageThreshold {
                result.breaksRoute = true
                // The bulk of this interval has already been charged by sample().
                // Only the uncommitted tail remains; never add the GPS chord again.
                if usedFallback && predictionEnabled && !interrupted {
                    result.meters = pendingMeters
                    result.estimatedMeters = pendingMeters
                }
            } else if distance == nil && normalPrediction {
                // Re-anchor after a rejected coordinate without charging its return jump.
                result.meters = pendingMeters
                result.usesMotion = true
                result.breaksRoute = true
            } else if let distance, distance.isFinite, distance >= 0 {
                let gpsMeters = min(distance, 70 * dt)
                result.meters = gpsMeters
                if normalPrediction {
                    let gpsVariance = pow(max(1, horizontalAccuracy * 0.25), 2)
                    let predictionVariance = max(1, velocityVariance * dt * dt)
                    let ceiling = horizontalAccuracy <= 10 ? 0.35 : 0.65
                    let weight = min(ceiling, max(0.1, gpsVariance / (gpsVariance + predictionVariance)))
                    result.rejectsCoordinate = gpsMeters > pendingMeters + max(15, horizontalAccuracy * 3)
                    result.meters = result.rejectsCoordinate ? pendingMeters
                        : gpsMeters * (1 - weight) + pendingMeters * weight
                    result.usesMotion = true
                }
                // Confirmed rest requires two good GPS speeds AND a small motion prediction.
                if validSpeed, speedAccuracy <= 0.5, gpsSpeed < 0.35,
                   let previousGPSSpeed, previousGPSSpeed < 0.35,
                   (!normalPrediction || speed < 0.5) {
                    result.meters = 0
                }
                result.meters = min(70 * dt, max(0, result.meters))
            }
            // Slowly estimate sensor bias on straight, well-observed GPS intervals.
            if normalPrediction, validSpeed, speedAccuracy <= 0.75, previousSpeedAccuracy <= 0.75,
               let previousGPSSpeed, let oldHeading, let newHeading, (0.5...3).contains(dt),
               abs(atan2(sin(newHeading - oldHeading), cos(newHeading - oldHeading))) < 0.17 {
                let observedAcceleration = (gpsSpeed - previousGPSSpeed) / dt
                let error = accelerationIntegral / dt - observedAcceleration
                if abs(error) < 1 { bias = min(0.3, max(-0.3, bias + 0.03 * (error - bias))) }
            }
        }

        if validSpeed {
            let variance = pow(max(0.2, speedAccuracy), 2)
            if normalPrediction {
                let gain = velocityVariance / (velocityVariance + variance)
                speed += gain * (gpsSpeed - speed)
                velocityVariance *= 1 - gain
            } else { speed = gpsSpeed; velocityVariance = variance }
            if gpsSpeed < 0.2 && speedAccuracy <= 0.5 { speed = 0 }
        }
        previousGPSSpeed = validSpeed ? gpsSpeed : nil
        previousSpeedAccuracy = validSpeed ? speedAccuracy : 10
        heading = newHeading
        predictionEnabled = motionAvailable && validSpeed && newHeading != nil
        gpsTime = time
        // Keep the monotonic sample clock when GPS arrives between motion callbacks.
        // The first sample after a new session establishes it without inventing elapsed data.
        if sampleTime == nil { sampleClock = nil }
        pendingMeters = 0
        coveredSeconds = 0
        accelerationIntegral = 0
        usedFallback = false
        interrupted = false
        return result
    }
}
