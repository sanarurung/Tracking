import Foundation
import CoreLocation
import CryptoKit

struct RoutePoint: Codable {
    let latitude: Double
    let longitude: Double
    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}

struct TripSnapshot: Codable {
    var meters: Double
    var segments: [[RoutePoint]]
    var finished: Bool
    var estimatedMeters: Double?
    var id: UUID?
    var startedAt: Date?
    var endedAt: Date?
    var fusedMeters: Double?
}

struct TripRecord: Codable, Identifiable {
    let id: UUID
    let startedAt: Date?
    let endedAt: Date?
    let savedAt: Date
    let meters: Double
    let estimatedMeters: Double
    let fusedMeters: Double
    let fareWon: Int
    let segments: [[RoutePoint]]
    let calculationVersion: String

    var isValid: Bool {
        meters.isFinite && meters >= 0 && estimatedMeters.isFinite && estimatedMeters >= 0
            && estimatedMeters <= meters + 0.001 && fusedMeters.isFinite && fusedMeters >= 0
            && fusedMeters <= meters + 0.001 && fareWon >= 0
            && (startedAt == nil || endedAt == nil || endedAt! >= startedAt!)
            && segments.joined().allSatisfy {
                (-90...90).contains($0.latitude) && (-180...180).contains($0.longitude)
            }
    }
}

/// One atomic file per trip. Retrying the same ID never duplicates a completed trip.
struct TripHistoryStore {
    let directory: URL

    static func legacyID(for snapshot: TripSnapshot) -> UUID {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .sortedKeys
        let data = (try? encoder.encode(snapshot)) ?? Data()
        let bytes = Array(SHA256.hash(data: data).prefix(16))
        let h = bytes.map { String(format: "%02x", $0) }
        let value = h[0..<4].joined() + "-" + h[4..<6].joined() + "-" + h[6..<8].joined()
            + "-" + h[8..<10].joined() + "-" + h[10..<16].joined()
        return UUID(uuidString: value)!
    }

    func save(_ record: TripRecord) throws {
        guard record.isValid else { throw CocoaError(.fileWriteInapplicableStringEncoding) }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let data = try JSONEncoder().encode(record)
        let file = directory.appendingPathComponent(record.id.uuidString).appendingPathExtension("json")
        #if os(iOS)
        try data.write(to: file, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        #else
        try data.write(to: file, options: .atomic)
        #endif
    }

    func load() throws -> (records: [TripRecord], unreadable: Int) {
        guard FileManager.default.fileExists(atPath: directory.path) else { return ([], 0) }
        let files = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)
        var records: [UUID: TripRecord] = [:]
        var unreadable = 0
        for file in files where file.pathExtension == "json" {
            do {
                let record = try JSONDecoder().decode(TripRecord.self, from: Data(contentsOf: file))
                guard record.isValid else { throw CocoaError(.fileReadCorruptFile) }
                records[record.id] = record
            } catch { unreadable += 1 } // Keep the unreadable file intact.
        }
        return (records.values.sorted { ($0.endedAt ?? $0.savedAt) > ($1.endedAt ?? $1.savedAt) }, unreadable)
    }
}
