import Foundation

struct SafetyDisplayCandidate {
    let point: SafetyPoint
    let x: Double
    let y: Double
}

/// Our display policy; these thresholds are not recovered Naver app constants.
enum SafetyDisplayPolicy {
    static func visible(_ candidates: [SafetyDisplayCandidate], zoom: Double,
                        minX: Double, minY: Double, maxX: Double, maxY: Double,
                        selectedID: String? = nil) -> [SafetyDisplayCandidate] {
        guard zoom.isFinite, zoom >= 14, maxX > minX, maxY > minY else { return [] }
        let limit = zoom >= 16 ? 24 : 12
        let ordered = candidates.filter { $0.point.id == selectedID } + candidates.filter { $0.point.id != selectedID }
        var result: [SafetyDisplayCandidate] = []
        var seen = Set<String>()
        for candidate in ordered {
            guard candidate.point.isValid, candidate.x.isFinite, candidate.y.isFinite,
                  candidate.x >= minX+18, candidate.x <= maxX-18,
                  candidate.y >= minY+18, candidate.y <= maxY-18,
                  zoom >= 16 || candidate.point.kind != .bump,
                  seen.insert(candidate.point.id).inserted else { continue }
            guard result.allSatisfy({ pow($0.x-candidate.x,2) + pow($0.y-candidate.y,2) >= 48*48 }) else { continue }
            result.append(candidate)
            if result.count == limit { break }
        }
        return result
    }
}
