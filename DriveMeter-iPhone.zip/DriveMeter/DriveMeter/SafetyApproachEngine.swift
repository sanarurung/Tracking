import Foundation
import CoreLocation

struct SafetyApproachWarning {
    let point: SafetyPoint
    let distance: Double
    let range: Double
    let updatedAt: Date
    func isFresh(at now: Date) -> Bool { (0...5).contains(now.timeIntervalSince(updatedAt)) }
}

struct SafetyApproachResult {
    var warning: SafetyApproachWarning?
    var announcement: SafetyApproachWarning?
}

/// GPS course corridor, not road/route matching. Do not infer a turn from proximity.
struct SafetyApproachEngine {
    private var announced: [String: Date] = [:]
    private var lastAnnouncement = Date.distantPast

    static func range(metresPerSecond speed: Double) -> Double {
        speed <= 70.0 / 3.6 ? 500 : 1_000
    }

    mutating func update(location: CLLocation, points: [SafetyPoint], now: Date) -> SafetyApproachResult {
        guard CLLocationCoordinate2DIsValid(location.coordinate),
              (0...5).contains(now.timeIntervalSince(location.timestamp)),
              (0...20).contains(location.horizontalAccuracy),
              location.speed.isFinite, (2...70).contains(location.speed),
              (0...3).contains(location.speedAccuracy),
              (0..<360).contains(location.course), (0...25).contains(location.courseAccuracy) else {
            return SafetyApproachResult()
        }
        let range = Self.range(metresPerSecond: location.speed)
        var candidates: [SafetyApproachWarning] = []
        for point in points where point.isValid {
            let distance = location.distance(from: CLLocation(latitude: point.latitude, longitude: point.longitude))
            // Re-arm only after leaving the facility, and never immediately after a pass.
            if let date = announced[point.id], now.timeIntervalSince(date) >= 120, distance > 1_200 {
                announced.removeValue(forKey: point.id)
            }
            guard distance >= 10, distance <= range else { continue }
            let latitude = location.coordinate.latitude * .pi / 180
            let otherLatitude = point.latitude * .pi / 180
            let longitudeDelta = (point.longitude-location.coordinate.longitude) * .pi / 180
            let bearing = atan2(sin(longitudeDelta)*cos(otherLatitude),
                                cos(latitude)*sin(otherLatitude)-sin(latitude)*cos(otherLatitude)*cos(longitudeDelta)) * 180 / .pi
            let delta = abs((bearing-location.course+540).truncatingRemainder(dividingBy: 360)-180)
            // Exclude rear/side facilities. Narrow lateral corridor reduces parallel-road prompts.
            guard delta <= 25, abs(distance*sin(delta * .pi/180)) <= 30 else { continue }
            candidates.append(SafetyApproachWarning(point: point, distance: distance, range: range, updatedAt: now))
        }
        let nearest = candidates.min { $0.distance == $1.distance ? $0.point.id < $1.point.id : $0.distance < $1.distance }
        guard let nearest else { return SafetyApproachResult() }
        var result = SafetyApproachResult(warning: nearest)
        if announced[nearest.point.id] == nil, now.timeIntervalSince(lastAnnouncement) >= 8 {
            announced[nearest.point.id] = now
            lastAnnouncement = now
            result.announcement = nearest
        }
        return result
    }
}
