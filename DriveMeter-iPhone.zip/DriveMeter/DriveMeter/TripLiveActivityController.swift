import ActivityKit
import Foundation

@MainActor
final class TripLiveActivityController {
    private struct Pending {
        let id: String
        let state: TripLiveState?
        let allowStart: Bool
        let force: Bool
    }
    private var pending: [Pending] = []
    private var worker: Task<Void, Never>?
    private var attempted = Set<String>()
    private var lastUpdate = Date.distantPast
    var onNotice: ((String?) -> Void)?

    func submit(id: UUID, state: TripLiveState?, allowStart: Bool, force: Bool) {
        let now = Date()
        guard force || now.timeIntervalSince(lastUpdate) >= 1 else { return }
        lastUpdate = now
        let item = Pending(id: id.uuidString, state: state, allowStart: allowStart, force: force)
        // Coalesce sensor samples, preserving ordered start/pause/end operations.
        if !force, let tail = pending.last, !tail.force, tail.id == item.id {
            pending[pending.count - 1] = item
        } else { pending.append(item) }
        guard worker == nil else { return }
        worker = Task { [weak self] in
            guard let self else { return }
            while !self.pending.isEmpty {
                let next = self.pending.removeFirst()
                await self.apply(next)
            }
            self.worker = nil
        }
    }

    func flush() async {
        while let task = worker { await task.value }
    }

    private func apply(_ item: Pending) async {
        let activities = Activity<TripActivityAttributes>.activities
        guard let state = item.state else {
            for activity in activities { await activity.end(nil, dismissalPolicy: .immediate) }
            return
        }
        let content = ActivityContent(state: state, staleDate: state.speedValidUntil)
        let existing = activities.first { $0.attributes.tripID == item.id }
        if state.phase == .finished {
            if let activity = existing {
                await activity.end(content, dismissalPolicy: .after(Date().addingTimeInterval(300)))
            }
            return
        }
        if let activity = existing {
            await activity.update(content)
            return
        }
        // A dismissed activity is not recreated by later GPS samples.
        guard item.allowStart, state.phase == .recording, !attempted.contains(item.id) else { return }
        guard ActivityAuthorizationInfo().areActivitiesEnabled else {
            onNotice?("잠금화면 표시를 사용하려면 설정에서 이 앱의 라이브 액티비티를 허용해 주세요.")
            return
        }
        for activity in activities { await activity.end(nil, dismissalPolicy: .immediate) }
        do {
            _ = try Activity.request(attributes: TripActivityAttributes(tripID: item.id), content: content, pushType: nil)
            attempted.insert(item.id)
            onNotice?(nil)
        } catch {
            onNotice?("라이브 액티비티를 시작하지 못했습니다. 앱에서 주행 정보를 확인해 주세요.")
        }
    }
}
