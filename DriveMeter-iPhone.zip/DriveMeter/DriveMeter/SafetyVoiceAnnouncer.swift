import AVFoundation

@MainActor
final class SafetyVoiceAnnouncer: NSObject, AVSpeechSynthesizerDelegate {
    private let speaker = AVSpeechSynthesizer()
    override init() {
        super.init()
        speaker.delegate = self
    }
    func announce(_ warning: SafetyApproachWarning) {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio, options: [.duckOthers])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch { return }
        var message = "전방 약 \(Int(warning.distance.rounded()))미터, \(warning.point.title)입니다."
        if let speed = warning.point.speedLimit, warning.point.kind == .camera {
            message += " 등록 제한속도는 시속 \(speed)킬로미터입니다."
        }
        let utterance = AVSpeechUtterance(string: message)
        utterance.voice = AVSpeechSynthesisVoice(language: "ko-KR")
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate
        speaker.speak(utterance)
    }
    func stop() {
        speaker.stopSpeaking(at: .immediate)
        deactivate()
    }
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) { deactivate() }
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) { deactivate() }
    private func deactivate() {
        try? AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
    }
}
