import SwiftUI
import CoreLocation

struct TripHistoryView: View {
    @ObservedObject var tracker: TripTracker
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if tracker.needsArchiveRetry {
                    Section {
                        Label("최근 주행의 저장이 완료되지 않았습니다", systemImage: "exclamationmark.triangle")
                            .foregroundStyle(.orange)
                        Button("저장 재시도") { tracker.retryArchive() }
                    }
                }
                if let warning = tracker.historyWarning {
                    Section {
                        Text(warning).font(.footnote).foregroundStyle(.secondary)
                        Button("목록 다시 읽기") { tracker.reloadHistory() }
                    }
                }
                if tracker.history.isEmpty {
                    ContentUnavailableView("저장된 주행이 없습니다", systemImage: "clock.arrow.circlepath",
                                           description: Text("주행을 종료하면 날짜, 거리, 요금과 경로가 자동으로 저장됩니다."))
                } else {
                    Section("저장된 주행 \(tracker.history.count)건") {
                        ForEach(tracker.history) { record in
                            NavigationLink { TripDetailView(record: record) } label: {
                                VStack(alignment: .leading, spacing: 8) {
                                    if let endedAt = record.endedAt {
                                        Text(endedAt, format: .dateTime.year().month().day().hour().minute())
                                            .font(.subheadline).foregroundStyle(.secondary)
                                    } else {
                                        Text("이전 버전에서 복원한 기록").font(.subheadline).foregroundStyle(.secondary)
                                    }
                                    HStack {
                                        Text("\((record.meters / 1000).formatted(.number.precision(.fractionLength(2)))) km")
                                        Spacer()
                                        Text("\(record.fareWon.formatted())원")
                                    }.font(.headline).monospacedDigit()
                                }.padding(.vertical, 5)
                            }
                        }
                    }
                }
                Section {
                    Text("새 주행을 시작해도 이 기록은 유지됩니다. 기록은 이 기기에 보관됩니다.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("주행 기록")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("완료") { dismiss() } } }
        }
    }
}

struct TripDetailView: View {
    let record: TripRecord

    var body: some View {
        List {
            Section {
                NaverRouteMap(segments: record.segments, isHistory: true)
                .frame(height: 280).clipShape(.rect(cornerRadius: 18))
                .overlay {
                    if record.segments.allSatisfy(\.isEmpty) {
                        Text("저장된 GPS 경로가 없습니다").padding().background(.regularMaterial, in: .capsule)
                    }
                }
            }.listRowInsets(EdgeInsets(top: 8, leading: 8, bottom: 8, trailing: 8))
            Section("최종 결과") {
                value("주행거리", "\((record.meters / 1000).formatted(.number.precision(.fractionLength(2)))) km")
                value("최종 요금", "\(record.fareWon.formatted())원")
                value("GPS + 센서 보정 구간", "\((record.fusedMeters / 1000).formatted(.number.precision(.fractionLength(2)))) km")
                value("센서 단독 추정 포함", "\((record.estimatedMeters / 1000).formatted(.number.precision(.fractionLength(2)))) km")
            }
            Section("주행 시각") {
                value("시작", timestamp(record.startedAt))
                value("종료", timestamp(record.endedAt))
            }
            Section {
                Text("지도에는 저장된 GPS 경로를 표시합니다. 센서 단독 추정 구간은 선이 끊겨 보일 수 있습니다. 최종 요금은 종료 시점의 금액을 보관한 값입니다.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("주행 상세").navigationBarTitleDisplayMode(.inline)
    }

    private func timestamp(_ date: Date?) -> String {
        date?.formatted(.dateTime.year().month().day().hour().minute().second()) ?? "이전 기록 · 시각 정보 없음"
    }
    private func value(_ title: String, _ value: String) -> some View {
        LabeledContent(title) { Text(value).monospacedDigit() }
    }
}
