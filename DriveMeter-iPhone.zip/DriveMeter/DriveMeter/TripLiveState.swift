import Foundation

struct TripLiveState: Codable, Hashable {
    enum Phase: String, Codable { case recording, paused, finished }
    let phase: Phase
    let meters: Double
    let fareWon: Int
    let speedKmh: Int?
    let speedValidUntil: Date?
    let updatedAt: Date

    init(phase: Phase, meters: Double, fareWon: Int, speedKmh: Double?,
         speedValidUntil: Date?, now: Date) {
        self.phase = phase
        self.meters = meters.isFinite ? max(0, meters) : 0
        self.fareWon = max(0, fareWon)
        self.updatedAt = now
        if phase == .recording, let speed = speedKmh, speed.isFinite,
           (0...252).contains(speed), let expiry = speedValidUntil, expiry > now {
            self.speedKmh = Int(speed.rounded())
            self.speedValidUntil = expiry
        } else {
            self.speedKmh = nil
            self.speedValidUntil = nil
        }
    }

    var distanceText: String { String(format: "%.2f", locale: Locale(identifier: "en_US_POSIX"), meters / 1000) }
    var compactDistanceText: String {
        String(format: meters < 10_000 ? "%.2f" : meters < 100_000 ? "%.1f" : "%.0f",
               locale: Locale(identifier: "en_US_POSIX"), meters / 1000)
    }
    var phaseText: String {
        switch phase { case .recording: return "주행 중"; case .paused: return "일시정지"; case .finished: return "주행 완료" }
    }
    func speedText(at now: Date, stale: Bool) -> String {
        guard !stale, phase == .recording, let speed = speedKmh,
              let expiry = speedValidUntil, now < expiry else { return "—" }
        return String(speed)
    }
}
