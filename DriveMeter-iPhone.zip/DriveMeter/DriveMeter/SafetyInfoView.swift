import SwiftUI

struct SafetyInfoView: View {
    @ObservedObject var tracker: TripTracker
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("주변 2km · 가까운 150개까지") {
                    if let warning = tracker.safetyWarning {
                        Label(warning, systemImage: "exclamationmark.triangle").foregroundStyle(.orange)
                    } else if tracker.currentLocation == nil {
                        Text("내 위치를 확인하면 주변 안전운전 정보를 표시합니다.")
                    } else if tracker.nearbySafety.isEmpty {
                        Text("주변에 수록된 정보가 없습니다. 시설이 없다는 의미는 아닙니다.")
                    }
                    ForEach(tracker.nearbySafety) { item in
                        HStack {
                            Image(systemName: item.point.kind == .bump ? "car.side.hill.up.fill" : "camera.fill")
                                .foregroundStyle(item.point.kind == .bump ? .orange : .red)
                            VStack(alignment: .leading) {
                                Text(item.point.title)
                                if let limit = item.point.speedLimit {
                                    Text("등록 제한속도 \(limit) km/h").font(.caption).foregroundStyle(.secondary)
                                }
                            }
                            Spacer()
                            Text("\(Int(item.distance.rounded()))m").monospacedDigit()
                        }
                    }
                }
                Section("데이터 안내") {
                    Text("카메라: 경찰청·지방자치단체 전국무인교통단속카메라 표준데이터 중 속도·신호 단속 지점. 행별 기준일은 서로 다릅니다.")
                    Text("방지턱: © OpenStreetMap contributors · ODbL. 등록된 지점만 표시하므로 누락이 있습니다.")
                    Text("수집일: 2026년 10월 28일 · 앱에 포함된 자료입니다. 실시간 갱신되지 않습니다.")
                    Text("거리는 직선거리이며 진행방향·주행 도로를 판별하지 않습니다. 반대편·인접 도로의 시설도 표시될 수 있습니다. 현장 표지판을 확인하세요.")
                    Link("카메라 원자료", destination: URL(string: "https://www.data.go.kr/data/15028200/standard.do")!)
                    Link("OpenStreetMap 저작권·라이선스", destination: URL(string: "https://www.openstreetmap.org/copyright")!)
                    Link("수록 데이터 다운로드 (소스 ZIP)", destination: URL(string: "https://github.com/sanarurung/Tracking/blob/main/DriveMeter-iPhone.zip")!)
                }.font(.footnote)
            }
            .navigationTitle("안전운전 정보")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("완료") { dismiss() } } }
        }
    }
}
