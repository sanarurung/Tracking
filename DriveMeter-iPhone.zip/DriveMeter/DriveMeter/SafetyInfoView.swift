import SwiftUI

struct SafetyInfoView: View {
    @ObservedObject var tracker: TripTracker
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("주변 2km · 가까운 150개까지") {
                    if let warning = tracker.safetyWarning {
                        Label(warning, systemImage: "exclamationmark.triangle").foregroundStyle(.orange)
                    } else if tracker.currentLocation == nil {
                        Text("내 위치를 확인하면 주변 안전운전 정보를 표시합니다.")
                    } else if tracker.nearbySafety.isEmpty {
                        Text("주변에 수록된 정보가 없습니다. 시설이 없다는 의미는 아닙니다.")
                    }
                    ForEach(tracker.nearbySafety) { item in
                        HStack {
                            Image(systemName: item.point.kind == .bump ? "car.side.hill.up.fill" : "camera.fill")
                                .foregroundStyle(item.point.kind == .bump ? .orange : .red)
                            VStack(alignment: .leading) {
                                Text(item.point.title)
                                if let limit = item.point.speedLimit {
                                    Text("등록 제한속도 \(limit) km/h").font(.caption).foregroundStyle(.secondary)
                                }
                            }
                            Spacer()
                            Text("\(Int(item.distance.rounded()))m").monospacedDigit()
                        }
                    }
                }
                Section("자동 사전 안내") {
                    Toggle("음성 안내", isOn: $tracker.voiceGuidanceEnabled)
                    Text("현재 GPS 속도가 시속 70km 이하면 500m, 초과하면 1km 범위에서 진행방향의 시설을 자동으로 안내합니다. 지점을 선택할 필요가 없습니다.")
                    Text("같은 지점의 반복 안내를 막습니다. 정지·GPS 불량·이동방향 미확인 시 안내하지 않습니다. 앱이 화면에 표시된 동안 동작합니다.")
                    Text("직선 진행방향을 사용하며 경로 탐색이나 도로 매칭이 아닙니다. 급커브·교차로에서 실제 진행 도로를 정확히 판단할 수 없습니다.")
                }
                Section("데이터 안내") {
                    Text("카메라는 공공데이터와 25m 이내에서 위치가 일치하고 OpenStreetMap의 차량 도로 위에도 등록된 252지점만 표시합니다. 제한속도가 두 자료에서 다르면 제외했습니다. 확인되지 않은 원자료 좌표로 되돌아가지 않습니다.")
                    Text("이 기준은 좌표 교차 확인이며 현장 설치 확인은 아닙니다. 보수적인 일부 자료이므로 카메라가 표시되지 않아도 시설이 없다는 의미는 아닙니다.")
                    Text("방지턱은 OpenStreetMap 등록 자료를 사용합니다. 지도에서는 확대 수준과 겹침에 따라 표지를 줄여 표시합니다.")
                    Text("© OpenStreetMap contributors · ODbL. 카메라·방지턱 자료는 2026년 10월 28일 수집한 스냅샷이며 실시간 갱신되지 않습니다.")
                    Link("카메라 원자료", destination: URL(string: "https://www.data.go.kr/data/15028200/standard.do")!)
                    Link("OpenStreetMap 저작권·라이선스", destination: URL(string: "https://www.openstreetmap.org/copyright")!)
                    Link("수록 데이터 다운로드 (소스 ZIP)", destination: URL(string: "https://github.com/sanarurung/Tracking/blob/main/DriveMeter-iPhone.zip")!)
                }.font(.footnote)
            }
            .navigationTitle("안전운전 정보")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("완료") { dismiss() } } }
        }
    }
}
