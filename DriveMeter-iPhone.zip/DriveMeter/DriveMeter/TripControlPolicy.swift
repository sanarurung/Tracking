import Foundation

enum TripControlCommand: String { case pause, resume, finish }

enum TripControlPolicy {
    static func accepted(_ command: TripControlCommand, requestedID: String, currentID: UUID,
                         phase: TripLiveState.Phase?) -> Bool {
        guard UUID(uuidString: requestedID) == currentID else { return false }
        switch (command, phase) {
        case (.pause, .recording), (.resume, .paused), (.finish, .recording), (.finish, .paused): return true
        default: return false
        }
    }
}
