import ActivityKit

struct TripActivityAttributes: ActivityAttributes {
    typealias ContentState = TripLiveState
    let tripID: String
}
