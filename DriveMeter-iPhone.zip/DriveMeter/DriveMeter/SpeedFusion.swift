import Foundation

/// Runs the bounded complementary velocity filter without charging any distance.
struct SpeedFusion {
    private var filter = DistanceFusion()
    private var lastGPS: (time: Double, speed: Double, accuracy: Double)?
    private var lastMotionTime: Double?
    private var hasHeading = false
    private var motionEnabled = false

    mutating func observeGPS(speed: Double, speedAccuracy: Double, course: Double,
                             horizontalAccuracy: Double, at time: Double, motionAvailable: Bool) {
        guard time.isFinite, speed.isFinite, (0...70).contains(speed),
              speedAccuracy.isFinite, (0...5).contains(speedAccuracy),
              horizontalAccuracy.isFinite, (0...30).contains(horizontalAccuracy),
              lastGPS.map({ time > $0.time }) ?? true else { return }
        if course.isFinite && (0..<360).contains(course) { hasHeading = true }
        _ = filter.observeGPS(distance: nil, speed: speed, speedAccuracy: speedAccuracy,
            course: course, horizontalAccuracy: horizontalAccuracy, at: time, motionAvailable: motionAvailable)
        lastGPS = (time, speed, speedAccuracy)
        motionEnabled = motionAvailable && hasHeading
    }

    mutating func sample(north: Double, west: Double, at time: Double, sensorTime: Double) {
        guard north.isFinite, west.isFinite, time.isFinite, sensorTime.isFinite else {
            invalidateMotion(); return
        }
        _ = filter.sample(north: north, west: west, at: time, sensorTime: sensorTime)
        lastMotionTime = time
    }

    mutating func invalidateMotion() {
        filter.invalidateMotion()
        motionEnabled = false
        lastMotionTime = nil
    }

    func reading(at time: Double) -> SpeedReading? {
        guard let gps = lastGPS, time.isFinite else { return nil }
        let age = time-gps.time
        guard age >= 0 else { return nil }
        if motionEnabled, !filter.interrupted, let motionTime = lastMotionTime,
           (0...0.5).contains(time-motionTime), age <= DistanceFusion.maximumOutage {
            return SpeedReading(metresPerSecond: filter.speed, accuracy: filter.speedStandardDeviation,
                timestamp: Date(timeIntervalSinceReferenceDate: motionTime),
                source: age >= DistanceFusion.outageThreshold ? .inertial : .gpsMotion,
                expiresAt: Date(timeIntervalSinceReferenceDate: gps.time + DistanceFusion.maximumOutage))
        }
        guard age <= 5 else { return nil }
        return SpeedReading(metresPerSecond: gps.speed, accuracy: gps.accuracy,
                            timestamp: Date(timeIntervalSinceReferenceDate: gps.time))
    }
}
