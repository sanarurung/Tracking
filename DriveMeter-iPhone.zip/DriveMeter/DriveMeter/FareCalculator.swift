import Foundation

enum FareCalculator {
    /// Partial kilometres are prorated; the final amount is rounded to the nearest won.
    static func won(meters: Double) -> Int {
        guard meters.isFinite, meters > 0 else { return 0 }
        let km = meters / 1_000
        let amount = min(km, 30) * 270
            + min(max(km - 30, 0), 70) * 250
            + max(km - 100, 0) * 220
        return Int(min(amount.rounded(), Double(Int.max / 2)))
    }
}
