// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "DriveMeterCore",
    platforms: [.macOS(.v13)],
    products: [.library(name: "DriveMeter", targets: ["DriveMeter"])],
    targets: [
        .target(name: "DriveMeter", path: "DriveMeter",
                exclude: ["TripActivityAttributes.swift", "TripLiveActivityController.swift", "DriveMeterApp.swift", "ContentView.swift", "TripTracker.swift", "TripHistoryView.swift", "NaverRouteMap.swift", "SafetyInfoView.swift", "SafetyMarkerArtwork.swift", "SafetyVoiceAnnouncer.swift", "SafetyCameras.json", "SafetyBumps.json",
                          "Info.plist", "PrivacyInfo.xcprivacy", "Assets.xcassets"],
                sources: ["FareCalculator.swift", "InertialDistance.swift", "DistanceFusion.swift", "TripHistory.swift", "SpeedReading.swift", "SafetyPoint.swift", "SafetyDisplayPolicy.swift", "SafetyApproachEngine.swift", "SpeedFusion.swift", "TripLiveState.swift"]),
        .testTarget(name: "DriveMeterTests", dependencies: ["DriveMeter"], path: "DriveMeterTests")
    ]
)
