# 네이버 주소 조회 중계 서버

서버 소스만 준비된 상태입니다. 배포된 서버나 실제 네이버 인증 연결은 아직 없습니다. 네이버 Client Secret은 앱·GitHub 소스·채팅에 넣지 마세요.

## 배포와 연결

1. 네이버 Cloud Maps 애플리케이션에서 **Reverse Geocoding**을 활성화합니다. 지도 표시용 Mobile Dynamic Map과 별도 기능입니다.
2. Node.js 22 이상 또는 Docker를 지원하고 HTTPS를 제공하는 서버에 이 폴더를 배포합니다. 실행 명령은 `node server.mjs`, 포트는 `PORT`(기본 8080)입니다. Docker 사용 시 이 폴더를 빌드 컨텍스트로 사용하세요. HTTPS 종단은 호스팅 또는 리버스 프록시에서 제공합니다. 임의 서버에 자동 배포하거나 유료 호스팅을 생성하지 않았습니다.
3. 호스팅의 비밀 환경 변수에 아래 세 값을 등록합니다.

| 환경 변수 | 값 |
| --- | --- |
| NAVER_MAPS_CLIENT_ID | 네이버 Maps Client ID |
| NAVER_MAPS_CLIENT_SECRET | 네이버 Maps Client Secret, 서버에만 보관 |
| DRIVEMETER_PROXY_TOKEN | 직접 생성한 16자 이상 무작위 접근 토큰, 네이버 키와 다른 값 |

4. 앱의 하단 주소 표시 영역을 누르고 `https://배포한서버/reverse-geocode`와 **중계 서버 접근 토큰**을 입력합니다. 네이버 Client Secret을 입력하는 곳이 아닙니다. 앱 접근 토큰은 기기 Keychain에 저장하며 비밀 키는 IPA에 포함하지 않습니다.
5. 위치 권한과 GPS 수신 상태에서 지역명/도로명 교대 표시를 확인합니다. 네이버 API 권한·키·서버 연결이 잘못되면 앱에 연결 확인 안내가 표시됩니다.

신규 Maps API는 `https://maps.apigw.ntruss.com/map-reversegeocode/v2/gc`를 사용합니다. 기존 AI NAVER API 계약의 키를 쓰는 경우에만 `NAVER_MAPS_LEGACY=1`을 지정하면 공식 기존 엔드포인트를 사용합니다.

## 동작 및 데이터

앱은 화면이 활성화되어 있고 최근 GPS 위치가 있을 때 `POST /reverse-geocode`에 위도·경도를 JSON 본문으로 보냅니다. 서버는 네이버에 경도,위도 순으로 `orders=admcode,legalcode,roadaddr`를 요청하고 `{source:"naver",district,road}`만 돌려줍니다. 지역명에는 시·구 또는 동 정보를, 도로명에는 `roadaddr.land.name`을 사용하며 건물 번호는 제외합니다. 도로명 결과가 없으면 null입니다.

5초 교대는 **화면 표시 주기**입니다. 네트워크 호출은 최소 10초 간격에 30m 이상 이동했거나 60초가 지났을 때 수행합니다. 응답에서 200m 이상 이동했거나 60초 이상 오래된 주소를 현재 주소로 표시하지 않습니다. GPS가 끊기면 위치 수신 대기를 표시합니다. 서버는 같은 좌표의 결과를 메모리에 30초간만 캐시합니다. 좌표나 토큰을 로그·파일로 남기지 않습니다. 실제 배포 플랫폼의 접근 로그·본문 로깅 설정도 직접 확인하세요.

좌표는 설정한 서버와 네이버에 전송됩니다. 응답 도로명은 좌표 주변의 도로명 주소이며 GPS와 주소 데이터 오차, 교차로·고가도로·평행도로에서 실제 주행 도로와 다를 수 있습니다. 주행 경로나 방향을 이용해 도로에 매칭하는 내비게이션 기능은 아닙니다.

## 호출 제한

기본 전체 요청 제한은 분당 30건(`REQUESTS_PER_MINUTE`), 네이버 요청은 UTC 날짜당 6000건(`NAVER_REQUESTS_PER_DAY`)입니다. 단일 프로세스 메모리 제한이므로 재시작 시 초기화되고 여러 인스턴스에 공유되지 않습니다. 계정 전체 과금 상한으로 간주하지 마세요. 여러 인스턴스 운영 시 API Gateway/공유 저장소에서 별도 제한하고 네이버 콘솔의 이용량을 관리하세요. 접근 토큰이 없으면 서버는 조회를 거부합니다. 인증 헤더·좌표를 다른 곳으로 보내는 리디렉션도 따르지 않습니다.

## 검증

`node --test proxy.test.mjs`

테스트는 가상의 주소와 모의 응답을 사용합니다. 실제 네이버 키나 사용자 위치를 쓰지 않습니다. 테스트 통과는 네이버 계정의 API 활성화·요금·실제 주소 정확도나 배포 성공을 확인한 것이 아닙니다.

공식 문서: [Reverse Geocoding](https://api.ncloud-docs.com/docs/application-maps-reversegeocoding), [Maps 인증 헤더](https://api.ncloud-docs.com/docs/application-maps-overview).
