import { timingSafeEqual } from 'node:crypto';

const clean = value => typeof value === 'string' ? value.trim().slice(0, 120) : '';
export function labelsFromNaver(payload) {
  if (![0, 3].includes(payload?.status?.code)) throw new Error('provider-status');
  const results = Array.isArray(payload.results) ? payload.results : [];
  const admin = results.find(x => x?.name === 'admcode') ?? results.find(x => x?.name === 'legalcode') ?? results.find(x => x?.region);
  const region = admin?.region ?? {};
  const province = clean(region.area1?.name);
  const city = clean(region.area2?.name);
  const dong = clean(region.area3?.name);
  let district;
  if (city.includes('구')) {
    const metro = /(?:특별시|광역시)$/.test(province) ? province.replace(/특별시$|광역시$/, '시') : '';
    district = [city.includes('시') ? '' : metro, city].filter(Boolean).join(' ');
  } else {
    district = [city || province, dong].filter(Boolean).filter((x, i, a) => a.indexOf(x) === i).join(' ');
  }
  const road = clean(results.find(x => x?.name === 'roadaddr')?.land?.name);
  return { source: 'naver', district: district || null, road: road || null };
}

export function createHandler(env, fetcher = fetch) {
  let minute = -1, count = 0, day = '', daily = 0;
  const cache = new Map();
  const respond = (status, value) => ({ status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, body: JSON.stringify(value) });
  const integer = (value, fallback) => Number.isSafeInteger(Number(value)) && Number(value) > 0 ? Number(value) : fallback;
  return async ({ method, path, authorization, body }) => {
    if (method !== 'POST' || path !== '/reverse-geocode') return respond(404, { error: 'not-found' });
    const token = env.DRIVEMETER_PROXY_TOKEN ?? '';
    if (token.length < 16 || !env.NAVER_MAPS_CLIENT_ID || !env.NAVER_MAPS_CLIENT_SECRET) return respond(503, { error: 'configuration-required' });
    const actual = Buffer.from(authorization ?? '');
    const expected = Buffer.from(`Bearer ${token}`);
    if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) return respond(401, { error: 'unauthorized' });
    if (Buffer.byteLength(body ?? '') > 1024) return respond(413, { error: 'request-too-large' });
    let point;
    try { point = JSON.parse(body); } catch { return respond(400, { error: 'invalid-json' }); }
    const { latitude, longitude } = point ?? {};
    if (typeof latitude !== 'number' || typeof longitude !== 'number' || !Number.isFinite(latitude) || !Number.isFinite(longitude)
        || Math.abs(latitude) > 90 || Math.abs(longitude) > 180) return respond(400, { error: 'invalid-coordinate' });
    const now = Date.now();
    if (minute !== Math.floor(now / 60000)) { minute = Math.floor(now / 60000); count = 0; }
    const today = new Date(now).toISOString().slice(0, 10);
    if (day !== today) { day = today; daily = 0; }
    if (++count > integer(env.REQUESTS_PER_MINUTE, 30)) return respond(429, { error: 'rate-limited' });
    const key = `${longitude.toFixed(5)},${latitude.toFixed(5)}`;
    const cached = cache.get(key);
    if (cached && cached.until > now) return respond(200, cached.data);
    if (daily >= integer(env.NAVER_REQUESTS_PER_DAY, 6000)) return respond(429, { error: 'daily-limit' });
    daily++;
    const origin = env.NAVER_MAPS_LEGACY === '1' ? 'https://naveropenapi.apigw.ntruss.com' : 'https://maps.apigw.ntruss.com';
    const url = new URL('/map-reversegeocode/v2/gc', origin);
    url.searchParams.set('coords', `${longitude},${latitude}`);
    url.searchParams.set('sourcecrs', 'epsg:4326');
    url.searchParams.set('output', 'json');
    url.searchParams.set('orders', 'admcode,legalcode,roadaddr');
    try {
      const response = await fetcher(url, {
        headers: { 'x-ncp-apigw-api-key-id': env.NAVER_MAPS_CLIENT_ID, 'x-ncp-apigw-api-key': env.NAVER_MAPS_CLIENT_SECRET },
        redirect: 'error', signal: AbortSignal.timeout(6000)
      });
      if (!response.ok) return respond(502, { error: 'naver-unavailable' });
      const text = await response.text();
      if (text.length > 256000) throw new Error('oversized-provider-response');
      const data = labelsFromNaver(JSON.parse(text));
      // Short-lived memory only. Do not log or persist request coordinates.
      for (const [k, value] of cache) if (value.until <= now) cache.delete(k);
      if (cache.size >= 500) cache.delete(cache.keys().next().value);
      cache.set(key, { until: now + 30000, data });
      return respond(200, data);
    } catch { return respond(502, { error: 'naver-unavailable' }); }
  };
}
