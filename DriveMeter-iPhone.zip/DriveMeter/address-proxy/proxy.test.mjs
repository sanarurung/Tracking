import test from 'node:test';
import assert from 'node:assert/strict';
import { labelsFromNaver, createHandler } from './proxy.mjs';

const payload = { status: { code: 0 }, results: [
  { name: 'admcode', region: { area1: { name: '가상도' }, area2: { name: '예시시 테스트구' }, area3: { name: '가상동' } } },
  { name: 'roadaddr', land: { name: '테스트로', number1: '123' } }
] };
const env = { NAVER_MAPS_CLIENT_ID: 'test-id', NAVER_MAPS_CLIENT_SECRET: 'server-only-secret', DRIVEMETER_PROXY_TOKEN: 'test-proxy-token-12345' };
const input = { method: 'POST', path: '/reverse-geocode', authorization: `Bearer ${env.DRIVEMETER_PROXY_TOKEN}`, body: JSON.stringify({ latitude: 35, longitude: 128 }) };
test('district and road are extracted without building number', () => {
  assert.deepEqual(labelsFromNaver(payload), { source: 'naver', district: '예시시 테스트구', road: '테스트로' });
});
test('no road result stays null', () => {
  assert.equal(labelsFromNaver({ status: { code: 0 }, results: [payload.results[0]] }).road, null);
});
test('no results and provider error are distinguished', () => {
  assert.equal(labelsFromNaver({ status: { code: 3 }, results: [] }).district, null);
  assert.throws(() => labelsFromNaver({ status: { code: 900 } }));
});
test('credentials are required and unauthorized calls never reach Naver', async () => {
  const never = () => { throw new Error('unexpected fetch'); };
  assert.equal((await createHandler({}, never)(input)).status, 503);
  assert.equal((await createHandler(env, never)({ ...input, authorization: 'wrong' })).status, 401);
});
test('invalid coordinates and oversized bodies are rejected', async () => {
  const handle = createHandler(env, () => { throw new Error('unexpected fetch'); });
  assert.equal((await handle({ ...input, body: '{"latitude":91,"longitude":128}' })).status, 400);
  assert.equal((await handle({ ...input, body: 'x'.repeat(1025) })).status, 413);
});
test('only the server sends Naver keys, longitude is first, response is compact and cached', async () => {
  let calls = 0;
  const handle = createHandler(env, async (url, options) => {
    calls++;
    assert.equal(url.origin, 'https://maps.apigw.ntruss.com');
    assert.equal(url.searchParams.get('coords'), '128,35');
    assert.equal(url.searchParams.get('orders'), 'admcode,legalcode,roadaddr');
    assert.equal(options.headers['x-ncp-apigw-api-key'], env.NAVER_MAPS_CLIENT_SECRET);
    return new Response(JSON.stringify(payload));
  });
  const response = await handle(input);
  assert.equal(response.status, 200);
  assert.equal(response.body.includes('secret'), false);
  assert.equal(response.body.includes('latitude'), false);
  await handle(input);
  assert.equal(calls, 1);
});
test('provider failures do not expose provider messages', async () => {
  const handle = createHandler(env, async () => new Response('private provider details', { status: 401 }));
  const result = await handle(input);
  assert.equal(result.status, 502);
  assert.equal(result.body.includes('private'), false);
});
test('request limit applies before another upstream call', async () => {
  const handle = createHandler({ ...env, REQUESTS_PER_MINUTE: '1' }, async () => new Response(JSON.stringify(payload)));
  assert.equal((await handle(input)).status, 200);
  assert.equal((await handle(input)).status, 429);
});
