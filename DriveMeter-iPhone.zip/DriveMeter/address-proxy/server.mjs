import http from 'node:http';
import { createHandler } from './proxy.mjs';

const handle = createHandler(process.env);
const server = http.createServer(async (request, response) => {
  response.setHeader('Cache-Control', 'no-store');
  let body = '';
  try {
    for await (const chunk of request) {
      body += chunk.toString('utf8');
      if (Buffer.byteLength(body) > 1024) {
        response.writeHead(413, { 'Content-Type': 'application/json' });
        response.end('{"error":"request-too-large"}');
        return;
      }
    }
    const result = await handle({ method: request.method, path: request.url, authorization: request.headers.authorization, body });
    response.writeHead(result.status, result.headers); response.end(result.body);
  } catch { response.writeHead(500); response.end('{"error":"request-failed"}'); }
});
server.requestTimeout = 10000;
server.headersTimeout = 10000;
server.listen(Number(process.env.PORT || 8080), '0.0.0.0', () => console.log('Address proxy listening'));
