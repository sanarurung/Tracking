import ActivityKit
import AppIntents
import WidgetKit
import SwiftUI

@main
struct TripActivityBundle: WidgetBundle {
    var body: some Widget { TripActivityWidget() }
}

struct TripActivityWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: TripActivityAttributes.self) { context in
            VStack(spacing: 12) {
                HStack {
                    Label("주행 요금계", systemImage: "steeringwheel")
                    Spacer()
                    Text(context.state.phaseText).foregroundStyle(.secondary)
                }.font(.caption)
                HStack {
                    metric(context.state.speedText(at: Date(), stale: context.isStale), unit: "km/h", title: "현재 속도")
                    Spacer()
                    metric(context.state.distanceText, unit: "km", title: "주행거리")
                }
                HStack {
                    Text("예상 요금")
                    Spacer()
                    Text("\(context.state.fareWon.formatted()) 원").bold()
                }.font(.subheadline)
                tripControls(context)
                if context.isStale && context.state.phase == .recording {
                    Text("속도 수신 대기 · 거리와 요금은 마지막 수신값").font(.caption2).foregroundStyle(.secondary)
                }
            }
            .padding(16)
            .activityBackgroundTint(Color.black.opacity(0.88))
            .activitySystemActionForegroundColor(.white)
            .foregroundStyle(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    metric(context.state.speedText(at: Date(), stale: context.isStale), unit: "km/h", title: "현재 속도")
                }
                DynamicIslandExpandedRegion(.trailing) {
                    metric(context.state.distanceText, unit: "km", title: "주행거리")
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(spacing: 10) {
                        HStack {
                            Text(context.state.phaseText)
                            Spacer()
                            Text("\(context.state.fareWon.formatted()) 원")
                        }.font(.caption).foregroundStyle(.secondary)
                        tripControls(context)
                    }
                }
            } compactLeading: {
                compact(context.state.speedText(at: Date(), stale: context.isStale), unit: "km/h")
            } compactTrailing: {
                compact(context.state.compactDistanceText, unit: "km")
            } minimal: {
                Text(context.state.speedText(at: Date(), stale: context.isStale))
                    .font(.caption2.bold()).monospacedDigit().foregroundStyle(.cyan)
            }
            .keylineTint(.cyan)
        }
    }
    @ViewBuilder
    private func tripControls(_ context: ActivityViewContext<TripActivityAttributes>) -> some View {
        if context.state.phase != .finished {
            HStack(spacing: 12) {
                if context.state.phase == .recording {
                    Button(intent: PauseTripIntent(tripID: context.attributes.tripID)) {
                        Label("일시정지", systemImage: "pause.fill").frame(maxWidth: .infinity)
                    }.tint(.blue)
                } else {
                    Button(intent: ResumeTripIntent(tripID: context.attributes.tripID)) {
                        Label("재개", systemImage: "play.fill").frame(maxWidth: .infinity)
                    }.tint(.blue)
                }
                Button(intent: FinishTripIntent(tripID: context.attributes.tripID)) {
                    Label("주행 종료", systemImage: "stop.fill").frame(maxWidth: .infinity)
                }.tint(.red)
            }.font(.subheadline.weight(.semibold)).buttonStyle(.bordered).controlSize(.regular)
        }
    }

    private func metric(_ value: String, unit: String, title: String) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(.caption2).foregroundStyle(.secondary)
            HStack(alignment: .firstTextBaseline, spacing: 3) {
                Text(value).font(.title2.bold()).monospacedDigit().minimumScaleFactor(0.6)
                Text(unit).font(.caption2)
            }.lineLimit(1)
        }
    }
    private func compact(_ value: String, unit: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 2) {
            Text(value).font(.caption.bold()).monospacedDigit()
            Text(unit).font(.system(size: 8))
        }.foregroundStyle(.cyan).lineLimit(1).minimumScaleFactor(0.6)
    }
}
